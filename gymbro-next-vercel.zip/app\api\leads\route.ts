import { NextResponse } from 'next/server';

interface LeadPayload {
  name?: string;
  phone?: string;
  city?: string;
  role?: string;
  count?: string;
  source?: string;
}

export async function POST(request: Request) {
  try {
    const body: LeadPayload = await request.json();

    if (!body.name || !body.phone) {
      return NextResponse.json(
        { success: false, error: 'نام و شماره تماس الزامی است.' },
        { status: 400 }
      );
    }

    // Clean phone number
    const cleanedPhone = body.phone.trim().replace(/\s+/g, '');
    if (cleanedPhone.length < 10) {
      return NextResponse.json(
        { success: false, error: 'شماره تلفن همراه معتبر نیست.' },
        { status: 400 }
      );
    }

    const leadRecord = {
      id: `lead_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: body.name.trim(),
      phone: cleanedPhone,
      city: body.city?.trim() || 'نامشخص',
      role: body.role || 'coach',
      count: body.count || '10-30',
      source: body.source || 'landing_modal',
      createdAt: new Date().toISOString(),
    };

    console.log('[GymBro Serverless API] New Lead Received:', leadRecord);

    return NextResponse.json({
      success: true,
      message: 'اطلاعات شما با موفقیت ثبت شد. تیم پشتیبانی جیم‌برو با شما تماس خواهد گرفت.',
      leadId: leadRecord.id,
      timestamp: leadRecord.createdAt,
    });
  } catch (error) {
    console.error('[GymBro Serverless API] Error parsing lead request:', error);
    return NextResponse.json(
      { success: false, error: 'خطای سرور در پردازش درخواست.' },
      { status: 500 }
    );
  }
}
