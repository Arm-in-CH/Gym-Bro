'use client';

import React, { useEffect } from 'react';
import { DumbbellSvg, KettlebellSvg, ShakerBottleSvg } from '../icons/GymIcons';
import { soundChomp } from '@/lib/audio';

interface CabbagePacmanLoaderProps {
  text?: string;
  subtext?: string;
}

export const CabbagePacmanLoader: React.FC<CabbagePacmanLoaderProps> = ({
  text = 'کلم باشگاهی در حال بلعیدن و هضم دمبل‌ها...',
  subtext = 'هوش مصنوعی در حال محاسبه و تبدیل به پروتئین...',
}) => {
  useEffect(() => {
    const interval = setInterval(() => {
      soundChomp();
    }, 380);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-2 text-center space-y-2.5 w-full">
      {/* Responsive Eating Card */}
      <div
        className="relative w-full max-w-[310px] sm:max-w-[360px] h-24 sm:h-28 bg-surface-900 rounded-3xl border border-surface-750 shadow-xl overflow-hidden"
        dir="ltr"
      >
        {/* The Cute Cabbage Character (On the Left, Facing Right) */}
        <div className="absolute left-2.5 sm:left-3.5 top-1/2 -translate-y-1/2 z-20 cabbage-chew-bob w-16 h-16 sm:w-20 sm:h-20 pointer-events-none">
          <svg viewBox="0 0 100 100" className="w-full h-full" fill="none">
            {/* Outer Curly Cabbage Leaves */}
            <circle cx="50" cy="54" r="38" fill="#15803d" />
            <path d="M 20 40 Q 50 15 80 40" stroke="#86efac" strokeWidth="3" fill="none" opacity="0.6" />
            <path d="M 18 64 Q 50 88 82 64" stroke="#16a34a" strokeWidth="2.5" fill="none" opacity="0.8" />

            {/* Main Green Head */}
            <circle cx="50" cy="54" r="35" fill="#22c55e" />

            {/* Red Gym Sweatband */}
            <rect x="18" y="26" width="64" height="12" rx="6" fill="#dc2626" />
            <rect x="42" y="28" width="16" height="8" rx="2" fill="#ffffff" />
            <text x="50" y="34.5" fill="#dc2626" fontSize="6.5" fontWeight="900" textAnchor="middle" dominantBaseline="middle">
              GYM
            </text>

            {/* Kawaii Anime Eyes (Looking Right towards the Food!) */}
            <circle cx="38" cy="48" r="4.5" fill="#0f172a" />
            <circle cx="40" cy="46" r="1.8" fill="#ffffff" />
            <circle cx="60" cy="48" r="4.5" fill="#0f172a" />
            <circle cx="62" cy="46" r="1.8" fill="#ffffff" />

            {/* Cute Pink Blush Cheeks */}
            <ellipse cx="28" cy="56" rx="4" ry="2.5" fill="#f472b6" opacity="0.85" />
            <ellipse cx="70" cy="56" rx="4" ry="2.5" fill="#f472b6" opacity="0.85" />

            {/* Pac-Man Mouth Cavity (Facing RIGHT towards incoming dumbbells!) */}
            <g className="mouth-chomp-right">
              <path d="M 48 64 Q 66 50 84 64 Q 66 78 48 64 Z" fill="#881337" />
              <ellipse cx="64" cy="67" rx="6" ry="3.5" fill="#fb7185" />
              <rect x="60" y="54" width="10" height="3" rx="1" fill="#ffffff" />
            </g>
          </svg>
        </div>

        {/* Eating Sparkles Burst */}
        <div className="absolute left-[54px] sm:left-[68px] top-1/2 -translate-y-1/2 pointer-events-none z-30">
          <div className="w-2.5 h-2.5 rounded-full bg-amber-400 crumb-sparkle blur-[0.5px]"></div>
          <div className="w-2 h-2 rounded-full bg-brand-400 crumb-sparkle blur-[0.5px] mt-0.5 ml-0.5"></div>
        </div>

        {/* The Conveyor Track: Dumbbells Gliding Straight Into Mouth (left: 0% is inside mouth) */}
        <div className="absolute left-[52px] sm:left-[66px] right-2.5 sm:right-3.5 top-0 bottom-0 pointer-events-none">
          {/* Item 1: Amber Dumbbell */}
          <div className="conveyor-eat-1 w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shadow-md">
            <DumbbellSvg className="w-3.5 h-3.5 sm:w-4 sm:h-4" color="#f59e0b" />
          </div>

          {/* Item 2: Brand Kettlebell */}
          <div className="conveyor-eat-2 w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-brand-500/20 text-brand-400 border border-brand-500/40 flex items-center justify-center shadow-md">
            <KettlebellSvg className="w-3.5 h-3.5 sm:w-4 sm:h-4" color="var(--brand-400)" />
          </div>

          {/* Item 3: Blue Protein Shaker */}
          <div className="conveyor-eat-3 w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/40 flex items-center justify-center shadow-md">
            <ShakerBottleSvg className="w-3.5 h-3.5 sm:w-4 sm:h-4" color="#60a5fa" />
          </div>

          {/* Item 4: Purple Heavy Dumbbell */}
          <div className="conveyor-eat-4 w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/40 flex items-center justify-center shadow-md">
            <DumbbellSvg className="w-3.5 h-3.5 sm:w-4 sm:h-4" color="#c084fc" />
          </div>
        </div>
      </div>

      <div className="space-y-0.5" dir="rtl">
        <span className="font-extrabold text-xs text-white block">{text}</span>
        <span className="text-[10px] text-brand-400 font-medium block">{subtext}</span>
      </div>
    </div>
  );
};
