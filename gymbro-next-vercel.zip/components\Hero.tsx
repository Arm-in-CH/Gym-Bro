'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  Smartphone,
  Award,
  Calculator,
  ArrowLeft,
  Share2,
  MessageCircle,
  Send,
  Copy,
  ChevronLeft,
  User,
  Scan,
  Droplet,
  Briefcase,
  CreditCard,
  AlertCircle,
  Building2,
  ShieldCheck,
  Bell,
} from 'lucide-react';
import { soundClick, soundSuccess } from '@/lib/audio';

interface HeroProps {
  onOpenCoachModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenCoachModal }) => {
  const [copyText, setCopyText] = useState('کپی متن و لینک');

  const pitchMessage = `سلام استاد گرامی وقتتون بخیر 🌹
پلتفرم هوشمند بدنسازی و مدیریت مربیان GymBro رو دیدید؟
برای مربیان و باشگاه‌ها پنل اختصاصی طراحی کردن:
✅ ارسال برنامه‌ها در کمتر از ۳ دقیقه با ویدیوی ۳۰۰ حرکت
✅ سیستم تمدید خودکار شهریه با پیامک (حذف کارت‌به‌کارت و فیش)
✅ اسکن هوش مصنوعی غذاهای ایرانی (کالری دقیق قورمه‌سبزی، کوبیده و سنگک)
معرفی کامل و تست آنلاین رو از لینک زیر ببینید:
https://gymbros.ir`;

  const handleShareWhatsApp = () => {
    soundClick();
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(pitchMessage)}`, '_blank');
  };

  const handleShareTelegram = () => {
    soundClick();
    window.open(`https://t.me/share/url?url=https://gymbros.ir&text=${encodeURIComponent(pitchMessage)}`, '_blank');
  };

  const handleCopy = () => {
    soundSuccess();
    if (typeof navigator !== 'undefined') {
      navigator.clipboard.writeText(pitchMessage).then(() => {
        setCopyText('کپی شد! ✅');
        setTimeout(() => setCopyText('کپی متن و لینک'), 3000);
      });
    }
  };

  return (
    <section className="relative pt-16 pb-24 lg:pt-24 lg:pb-36 radial-bg-top grid-pattern overflow-hidden">
      {/* Background Floating Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-brand-500/10 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute top-1/3 left-10 w-[300px] h-[300px] bg-cyber-500/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-[300px] h-[300px] bg-fire-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Top Announcement Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-surface-900/90 border border-brand-500/30 shadow-lg text-xs font-semibold text-slate-300">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500" />
            </span>
            <span className="text-brand-400 font-bold">انقلاب دیجیتال در بدنسازی ایران:</span>
            <span>اکوسیستم یکپارچه ورزشکار، مربی و باشگاه‌دار</span>
            <ArrowLeft className="w-3.5 h-3.5 text-slate-400" />
          </div>
        </div>

        {/* Main Headline */}
        <div className="text-center max-w-4xl mx-auto space-y-6">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight leading-[1.15]">
            قدرت بدنسازی در دستان شما، <br />
            <span className="gradient-text-emerald">هوشمند، متصل و بدون مرز.</span>
          </h1>
          <p className="text-base sm:text-lg lg:text-xl text-slate-300 font-normal leading-relaxed max-w-3xl mx-auto">
            پایان دوران برنامه‌های کاغذی، فایل‌های پراکنده اکسل و پیگیری‌های کلافه‌کننده در واتساپ.{' '}
            <strong className="text-white">GymBro</strong> اولین سوپراپلیکیشن ایرانی است که{' '}
            <span className="text-brand-400 font-semibold">ورزشکاران</span> را به رژیم و تمرین هوشمند،{' '}
            <span className="text-fire-500 font-semibold">مربیان</span> را به پنل CRM خودکار درآمدزایی، و{' '}
            <span className="text-cyber-500 font-semibold">باشگاه‌ها</span> را به گیت‌های دیجیتال و باشگاه ابری متصل می‌کند.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <Link
              href="/app"
              onClick={() => soundSuccess()}
              className="px-8 py-4 rounded-2xl bg-brand-500 hover:bg-brand-400 text-slate-950 font-black text-sm shadow-glow-emerald transition-all hover:scale-105 flex items-center gap-3"
            >
              <Smartphone className="w-5 h-5" />
              <span>تست زنده وب‌اپلیکیشن (بدون نصب)</span>
            </Link>

            <button
              onClick={() => {
                soundClick();
                onOpenCoachModal();
              }}
              className="px-7 py-4 rounded-2xl bg-fire-600 hover:bg-fire-500 text-white font-black text-sm shadow-glow-orange transition-all hover:scale-105 flex items-center gap-2"
            >
              <Award className="w-4 h-4" />
              <span>دریافت پنل آزمایشی مربیان و باشگاه</span>
            </button>

            <a
              href="#calculator"
              onClick={() => soundClick()}
              className="px-7 py-4 rounded-2xl bg-surface-900 hover:bg-surface-850 text-slate-300 font-bold text-sm border border-surface-750 transition flex items-center gap-2"
            >
              <Calculator className="w-4 h-4 text-fire-400" />
              <span>محاسبه درآمد ماهانه</span>
            </a>
          </div>

          {/* Social Proof Stats Mini Strip */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto pt-10 text-center">
            <div className="p-4 rounded-2xl bg-surface-900/60 border border-surface-800">
              <div className="text-2xl sm:text-3xl font-black text-white font-mono">۹۸.۶٪</div>
              <div className="text-xs text-slate-400 mt-1">پایبندی شاگردان به برنامه</div>
            </div>
            <div className="p-4 rounded-2xl bg-surface-900/60 border border-surface-800">
              <div className="text-2xl sm:text-3xl font-black text-brand-400 font-mono">۳ دقیقه</div>
              <div className="text-xs text-slate-400 mt-1">میانگین ثبت برنامه جدید توسط مربی</div>
            </div>
            <div className="p-4 rounded-2xl bg-surface-900/60 border border-surface-800">
              <div className="text-2xl sm:text-3xl font-black text-fire-400 font-mono">+۴۰٪</div>
              <div className="text-xs text-slate-400 mt-1">افزایش تمدید شهریه باشگاه‌ها</div>
            </div>
            <div className="p-4 rounded-2xl bg-surface-900/60 border border-surface-800">
              <div className="text-2xl sm:text-3xl font-black text-cyber-500 font-mono">۱۰۰٪ بومی</div>
              <div className="text-xs text-slate-400 mt-1">دیتابیس غذاهای اصیل ایرانی</div>
            </div>
          </div>

          {/* Coach Referral & Quick Share Strip */}
          <div className="mt-8 p-4 rounded-2xl bg-surface-900/90 border border-fire-500/30 flex flex-wrap items-center justify-between gap-4 max-w-4xl mx-auto shadow-xl">
            <div className="flex items-center gap-3 text-right">
              <div className="w-10 h-10 rounded-xl bg-fire-500/20 text-fire-400 flex items-center justify-center shrink-0">
                <Share2 className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">ارسال پرزنتیشن به مربیان همکار یا مدیران باشگاه</div>
                <div className="text-[11px] text-slate-400">لینک اختصاصی تست و معرفی پلتفرم را با ۱ کلیک در واتساپ یا تلگرام فوروارد کنید:</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleShareWhatsApp}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow-sm"
              >
                <MessageCircle className="w-4 h-4" />
                <span>ارسال در واتساپ</span>
              </button>
              <button
                onClick={handleShareTelegram}
                className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow-sm"
              >
                <Send className="w-4 h-4" />
                <span>ارسال در تلگرام</span>
              </button>
              <button
                onClick={handleCopy}
                className="px-3.5 py-2 rounded-xl bg-surface-800 hover:bg-surface-750 text-slate-300 font-bold text-xs flex items-center gap-1.5 transition border border-surface-700"
              >
                <Copy className="w-4 h-4" />
                <span>{copyText}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Hero Visual Showcase: Floating Holographic Mockup */}
        <div className="mt-16 lg:mt-20 max-w-5xl mx-auto relative">
          <div className="p-3 sm:p-5 rounded-[40px] bg-gradient-to-b from-surface-800/80 via-surface-900/90 to-surface-950 border border-surface-750 shadow-2xl relative overflow-hidden">
            {/* Top Browser Bar Mockup */}
            <div className="flex items-center justify-between pb-4 border-b border-surface-800 px-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-rose-500" />
                <div className="w-3 h-3 rounded-full bg-amber-500" />
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
                <span className="mr-4 text-xs font-mono text-slate-500">https://gymbroapp.ir</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="inline-block w-2 h-2 rounded-full bg-brand-500 animate-pulse" />
                <span>اکوسیستم زنده بدنسازی</span>
              </div>
            </div>

            {/* Triple Dashboard Preview Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
              {/* Card 1: Athlete Live Feed */}
              <div className="glass-card p-5 rounded-3xl border border-brand-500/30 space-y-3 relative overflow-hidden group">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-brand-400 flex items-center gap-1.5">
                    <User className="w-4 h-4" /> پنل ورزشکار
                  </span>
                  <span className="text-[10px] bg-brand-500/20 text-brand-300 px-2 py-0.5 rounded-full font-mono">امروز: سینه و جلو‌بازو</span>
                </div>
                <div className="space-y-2">
                  <div className="p-3 bg-surface-950/70 rounded-2xl border border-surface-800 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-brand-500/20 flex items-center justify-center text-brand-400">
                        <Scan className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">اسکنر ناهار: چلو کباب کوبیده</div>
                        <div className="text-[10px] text-slate-400">۶۵۰ کیلوکالری • ۴۲ گرم پروتئین</div>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-emerald-400 font-mono">ثبت شد</span>
                  </div>

                  <div className="p-3 bg-surface-950/70 rounded-2xl border border-surface-800 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-blue-500/20 flex items-center justify-center text-blue-400">
                        <Droplet className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">هیدراتاسیون ۲,۴۰۰ از ۳,۵۰۰ ml</div>
                        <div className="text-[10px] text-slate-400">یادآور هوشمند بعدی: ۳۵ دقیقه دیگر</div>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-blue-400 font-mono">۶۸٪</span>
                  </div>
                </div>
              </div>

              {/* Card 2: Trainer CRM Feed */}
              <div className="glass-card p-5 rounded-3xl border border-fire-500/30 space-y-3 relative overflow-hidden group">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-fire-400 flex items-center gap-1.5">
                    <Briefcase className="w-4 h-4" /> پنل مربی (CRM)
                  </span>
                  <span className="text-[10px] bg-fire-500/20 text-fire-300 px-2 py-0.5 rounded-full font-mono">۴۸ شاگرد فعال</span>
                </div>
                <div className="space-y-2">
                  <div className="p-3 bg-surface-950/70 rounded-2xl border border-surface-800 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-fire-500/20 flex items-center justify-center text-fire-400">
                        <CreditCard className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">تمدید دوره: سهراب مرادی</div>
                        <div className="text-[10px] text-slate-400">واریز آنلاین به حساب: ۱,۵۰۰,۰۰۰ ت</div>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-emerald-400 font-mono">موفق</span>
                  </div>

                  <div className="p-3 bg-surface-950/70 rounded-2xl border border-surface-800 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400">
                        <AlertCircle className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">شاگرد نیازمند بازبینی رژیم</div>
                        <div className="text-[10px] text-slate-400">افت ۵۰۰ کالری در ۲ روز گذشته</div>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-amber-400 font-mono">هشدار هوشمند</span>
                  </div>
                </div>
              </div>

              {/* Card 3: Gym & Turnstile Feed */}
              <div className="glass-card p-5 rounded-3xl border border-cyber-500/30 space-y-3 relative overflow-hidden group">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-cyber-500 flex items-center gap-1.5">
                    <Building2 className="w-4 h-4" /> پنل باشگاه و گیت
                  </span>
                  <span className="text-[10px] bg-cyber-500/20 text-purple-300 px-2 py-0.5 rounded-full font-mono">تردد زنده سالن: ۷۲ نفر</span>
                </div>
                <div className="space-y-2">
                  <div className="p-3 bg-surface-950/70 rounded-2xl border border-surface-800 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400">
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">گیت ورود #۱ (RFID اسکن شد)</div>
                        <div className="text-[10px] text-slate-400">اشتراک طلایی معتبر تا ۱۵ روز دیگر</div>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-emerald-400 font-mono">باز شد</span>
                  </div>

                  <div className="p-3 bg-surface-950/70 rounded-2xl border border-surface-800 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-rose-500/20 flex items-center justify-center text-rose-400">
                        <Bell className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">ارسال پیامک تمدید اتوماتیک</div>
                        <div className="text-[10px] text-slate-400">برای ۱۴ عضو با سررسید ۳ روز آینده</div>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-rose-400 font-mono">ارسال شد</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Showcase Action */}
            <div className="mt-4 pt-3 border-t border-surface-800 flex flex-wrap items-center justify-between gap-3 px-2 text-xs">
              <span className="text-slate-400">💡 هر سه ماژول در یک دیتابیس هماهنگ لحظه‌ای (Real-time Cloud Sync) متصل هستند.</span>
              <Link href="/app" className="text-brand-400 font-bold hover:underline flex items-center gap-1">
                ورود به محیط شبیه‌ساز زنده <ChevronLeft className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
