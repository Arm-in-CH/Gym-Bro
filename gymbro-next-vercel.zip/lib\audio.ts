// Web Audio API Synthesizer (Zero-Asset Lightweight Sound Engine)

let actx: AudioContext | null = null;
let soundEnabled = true;

export function isSoundEnabled(): boolean {
  return soundEnabled;
}

export function setSoundEnabled(enabled: boolean): void {
  soundEnabled = enabled;
}

export function playTone(freq: number, type: OscillatorType, duration: number, volume = 0.08): void {
  if (!soundEnabled || typeof window === 'undefined') return;
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    if (!actx) actx = new AudioContextClass();
    if (actx.state === 'suspended') actx.resume();

    const osc = actx.createOscillator();
    const gain = actx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, actx.currentTime);
    gain.gain.setValueAtTime(volume, actx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + duration);

    osc.connect(gain);
    gain.connect(actx.destination);

    osc.start();
    osc.stop(actx.currentTime + duration);
  } catch {
    // Ignore audio context constraints
  }
}

export function soundClick(): void {
  playTone(600, 'sine', 0.05, 0.08);
}

export function soundTab(): void {
  playTone(440, 'triangle', 0.08, 0.08);
}

export function soundSuccess(): void {
  playTone(523.25, 'sine', 0.1, 0.1);
  setTimeout(() => playTone(659.25, 'sine', 0.15, 0.1), 80);
}

export function soundChomp(): void {
  if (!soundEnabled || typeof window === 'undefined') return;
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    if (!actx) actx = new AudioContextClass();
    if (actx.state === 'suspended') actx.resume();

    const osc = actx.createOscillator();
    const gain = actx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(260, actx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(110, actx.currentTime + 0.08);
    gain.gain.setValueAtTime(0.12, actx.currentTime);
    gain.gain.linearRampToValueAtTime(0.01, actx.currentTime + 0.08);

    osc.connect(gain);
    gain.connect(actx.destination);

    osc.start();
    osc.stop(actx.currentTime + 0.08);
  } catch {}
}

export function soundWaterDrop(): void {
  playTone(800, 'sine', 0.12, 0.15);
}
