'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Sparkles,
  Smartphone,
  Apple,
  Monitor,
  Flame,
  LayoutDashboard,
  ScanLine,
  Users,
  Briefcase,
  Database,
  Droplet,
  CheckCircle2,
  Phone,
  Mail,
  Camera,
  Play,
  Check,
  X,
  Plus,
  RefreshCw,
  Calculator as CalcIcon,
} from 'lucide-react';
import { DumbbellSvg, KettlebellSvg, ShakerBottleSvg } from '../icons/GymIcons';
import { CabbagePacmanLoader } from './CabbagePacmanLoader';
import { IRANIAN_FOODS, TRAINERS_LIST, TODAY_WORKOUT } from '@/lib/data';
import { soundClick, soundSuccess, soundWaterDrop } from '@/lib/audio';

export const SimulatorCanvas: React.FC = () => {
  const [deviceMode, setDeviceMode] = useState<'ios' | 'android' | 'desktop'>('ios');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'workout' | 'scanner' | 'trainers' | 'crm' | 'database'>('dashboard');
  const [currentTheme, setCurrentTheme] = useState('emerald');
  const [isHomeMode, setIsHomeMode] = useState(false);
  const [isNativeMobile, setIsNativeMobile] = useState(false);

  // Modals & States
  const [showDemoLoader, setShowDemoLoader] = useState(false);
  const [showWaterModal, setShowWaterModal] = useState(false);
  const [showOneRmModal, setShowOneRmModal] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Water Tracker
  const [waterConsumedMl, setWaterConsumedMl] = useState(2400);
  const [isWaterReminderOn, setIsWaterReminderOn] = useState(true);
  const [waterInterval, setWaterInterval] = useState(45);

  // Food Scanner
  const [selectedDishKey, setSelectedDishKey] = useState<string>('koobideh');
  const [isScanningFood, setIsScanningFood] = useState(false);
  const [scanSuccess, setScanSuccess] = useState(false);

  // 1RM Calculator
  const [weightInput, setWeightInput] = useState<number>(80);
  const [repsInput, setRepsInput] = useState<number>(8);
  const [calculated1Rm, setCalculated1Rm] = useState<number>(100);

  // Workout Timer
  const [timerSec, setTimerSec] = useState<number>(90);
  const [isTimerActive, setIsTimerActive] = useState<boolean>(false);

  // Detect native mobile viewport
  useEffect(() => {
    const checkMobile = () => {
      if (typeof window !== 'undefined') {
        setIsNativeMobile(window.innerWidth < 640);
      }
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Timer countdown
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerActive && timerSec > 0) {
      interval = setInterval(() => setTimerSec((prev) => prev - 1), 1000);
    } else if (timerSec === 0 && isTimerActive) {
      soundSuccess();
      setIsTimerActive(false);
      showToast('استراحت تمام شد! ست بعدی را شروع کنید.');
    }
    return () => clearInterval(interval);
  }, [isTimerActive, timerSec]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const calculateOneRm = () => {
    soundClick();
    // Brzycki Formula: Weight / (1.0278 - (0.0278 * Reps))
    const result = Math.round(weightInput / (1.0278 - 0.0278 * repsInput));
    setCalculated1Rm(result);
  };

  const handleStartScan = () => {
    soundClick();
    setIsScanningFood(true);
    setScanSuccess(false);
    setTimeout(() => {
      setIsScanningFood(false);
      setScanSuccess(true);
      soundSuccess();
      showToast('ارزش غذایی با موفقیت شناسایی شد!');
    }, 2400);
  };

  const activeDish = IRANIAN_FOODS[selectedDishKey] || IRANIAN_FOODS.koobideh;

  // Render simulator internal screen content
  const renderScreenContent = () => {
    return (
      <div className="flex-1 overflow-y-auto pb-20 p-4 space-y-4 text-right" dir="rtl">
        {/* ======================= TAB 1: ATHLETE DASHBOARD ======================= */}
        {activeTab === 'dashboard' && (
          <div className="space-y-4">
            {/* Header Greeting */}
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] text-brand-400 font-bold block">عصر بخیر، آرمین قهرمان ⚡</span>
                <h2 className="text-base font-black text-white">آماده‌ای برای رکورد جدید؟</h2>
              </div>
              <div className="w-10 h-10 rounded-2xl bg-surface-850 border border-surface-750 flex items-center justify-center text-white font-bold text-xs">
                آ.ص
              </div>
            </div>

            {/* Daily Quote / Motivation */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-brand-950/70 to-surface-900 border border-brand-500/30 text-xs">
              <span className="text-brand-300 font-bold block">نکته مربی (استاد فرزین):</span>
              <p className="text-slate-300 text-[11px] mt-0.5 leading-relaxed">
                «تمرکز امروز روی انقباض قله حرکت در پرس سینه است. وزنه را با کنترل پایین بیاور.»
              </p>
            </div>

            {/* Macros Summary Grid */}
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-3 rounded-2xl bg-surface-900 border border-surface-800">
                <span className="text-[10px] text-slate-400 block">کالری مصرفی</span>
                <span className="text-base font-black text-white font-mono">۱,۸۵۰</span>
                <span className="text-[9px] text-slate-500 block">از ۲,۴۰۰</span>
              </div>
              <div className="p-3 rounded-2xl bg-surface-900 border border-surface-800">
                <span className="text-[10px] text-slate-400 block">پروتئین</span>
                <span className="text-base font-black text-brand-400 font-mono">۱۴۲g</span>
                <span className="text-[9px] text-slate-500 block">هدف ۱۶۰g</span>
              </div>
              <div className="p-3 rounded-2xl bg-surface-900 border border-surface-800">
                <span className="text-[10px] text-slate-400 block">کربوهیدرات</span>
                <span className="text-base font-black text-amber-400 font-mono">۲۱۰g</span>
                <span className="text-[9px] text-slate-500 block">هدف ۲۳۰g</span>
              </div>
            </div>

            {/* Hydration Tracker Card */}
            <div className="p-4 rounded-3xl bg-surface-900 border border-blue-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
                    <Droplet className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-black text-white">هیدراتاسیون هوشمند روزانه</h3>
                    <span className="text-[10px] text-slate-400">هدف: ۳,۵۰۰ میلی‌لیتر</span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    soundClick();
                    setShowWaterModal(true);
                  }}
                  className="px-2.5 py-1 bg-surface-800 hover:bg-surface-750 text-blue-300 rounded-lg text-[10px] font-bold border border-surface-700 transition"
                >
                  تنظیمات
                </button>
              </div>

              {/* Progress bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-white font-bold">{waterConsumedMl} ml</span>
                  <span className="text-blue-400">{Math.round((waterConsumedMl / 3500) * 100)}%</span>
                </div>
                <div className="w-full h-2.5 bg-surface-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-600 to-cyan-400 transition-all duration-500"
                    style={{ width: `${Math.min(100, (waterConsumedMl / 3500) * 100)}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[10px] text-slate-400">
                  {isWaterReminderOn ? `یادآور هر ${waterInterval} دقیقه فعال است` : 'یادآور غیرفعال'}
                </span>
                <button
                  onClick={() => {
                    soundWaterDrop();
                    setWaterConsumedMl((prev) => Math.min(4500, prev + 250));
                    showToast('+۲۵۰ میلی‌لیتر آب ثبت شد 💧');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-black text-[11px] flex items-center gap-1 transition shadow-md"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>ثبت ۱ لیوان (۲۵۰ml)</span>
                </button>
              </div>
            </div>

            {/* Today's Workout Quick Entry */}
            <div className="p-4 rounded-3xl bg-surface-900 border border-surface-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center">
                    <Flame className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-black text-white">برنامه تمرینی امروز</h3>
                    <span className="text-[10px] text-slate-400">سینه، زیربغل و اسکوات پا (۴ حرکت)</span>
                  </div>
                </div>
                <span className="text-[10px] bg-brand-500/20 text-brand-300 px-2 py-0.5 rounded-full font-bold">
                  آماده شروع
                </span>
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => {
                    soundClick();
                    setActiveTab('workout');
                  }}
                  className="flex-1 py-2.5 bg-brand-500 hover:bg-brand-600 text-slate-950 font-black text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-1.5"
                >
                  <DumbbellSvg className="w-4 h-4" color="#050811" />
                  <span>شروع لاگر تمرین</span>
                </button>

                <button
                  onClick={() => {
                    soundClick();
                    setActiveTab('scanner');
                  }}
                  className="px-3.5 py-2.5 bg-surface-800 hover:bg-surface-750 text-slate-200 font-bold text-xs rounded-xl border border-surface-700 transition flex items-center gap-1.5"
                >
                  <Camera className="w-4 h-4 text-brand-400" />
                  <span>اسکن غذا</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ======================= TAB 2: WORKOUT LOGGER ======================= */}
        {activeTab === 'workout' && (
          <div className="space-y-4">
            <div className="bg-surface-900 p-4 rounded-3xl border border-surface-800 flex justify-between items-center">
              <div>
                <h3 className="font-black text-sm text-white">جلسه تمرینی روز اول (فول‌بادی)</h3>
                <span className="text-xs text-slate-400">
                  {isHomeMode ? 'حالت تمرین در خانه (کش و وزن بدن)' : 'حالت باشگاه (هالتر و دستگاه)'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    soundClick();
                    setShowOneRmModal(true);
                  }}
                  className="p-2 bg-surface-800 hover:bg-surface-750 text-brand-400 rounded-xl border border-surface-700 text-xs font-bold"
                  title="محاسبه 1RM"
                >
                  <CalcIcon className="w-4 h-4" />
                </button>

                <button
                  onClick={() => {
                    soundClick();
                    setIsHomeMode(!isHomeMode);
                    showToast(!isHomeMode ? 'برنامه به تمرین در خانه تبدیل شد!' : 'به حالت باشگاه برگشتید!');
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 border ${
                    isHomeMode
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                      : 'bg-surface-800 text-amber-300 border-amber-500/30'
                  }`}
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{isHomeMode ? 'سوئیچ باشگاه' : 'سوئیچ خانه'}</span>
                </button>
              </div>
            </div>

            {/* Rest Timer Widget */}
            <div className="p-3 bg-surface-900 rounded-2xl border border-surface-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-brand-500/20 text-brand-400 flex items-center justify-center font-bold">
                  ⏱️
                </div>
                <div>
                  <span className="font-bold text-white block">تایمر استراحت ست‌ها:</span>
                  <span className="font-mono text-brand-400 text-xs font-bold">{timerSec} ثانیه</span>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    soundClick();
                    setTimerSec(90);
                    setIsTimerActive(true);
                  }}
                  className="px-3 py-1 bg-brand-500 text-slate-950 rounded-xl text-xs font-bold hover:bg-brand-400 transition"
                >
                  شروع ۹۰ث
                </button>
                <button
                  onClick={() => {
                    soundClick();
                    setIsTimerActive(false);
                    setTimerSec(90);
                  }}
                  className="px-2 py-1 bg-surface-800 text-slate-400 rounded-xl text-xs"
                >
                  ریست
                </button>
              </div>
            </div>

            {/* Exercise List */}
            <div className="space-y-3">
              {TODAY_WORKOUT.map((item, idx) => (
                <div key={item.id} className="p-4 bg-surface-900 rounded-3xl border border-surface-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-brand-400 font-bold block">حرکت #{idx + 1}</span>
                      <h4 className="font-black text-sm text-white">{item.name}</h4>
                    </div>
                    <span className="text-[10px] bg-surface-800 text-slate-300 px-2.5 py-1 rounded-xl">
                      {item.muscle}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-normal bg-surface-850 p-2.5 rounded-xl border border-surface-800">
                    {isHomeMode ? item.homeVersion : item.gymVersion}
                  </p>

                  <div className="flex items-center justify-between pt-1 text-xs">
                    <span className="text-slate-400 text-[11px]">
                      {item.sets} ست × {item.reps} تکرار
                    </span>
                    <button
                      onClick={() => {
                        soundSuccess();
                        showToast(`ست حرکت ${item.name} ثبت شد!`);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-brand-500/20 text-brand-400 hover:bg-brand-500/30 text-xs font-bold flex items-center gap-1 transition"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>ثبت ست انجام‌شده</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ======================= TAB 3: FOOD SCANNER ======================= */}
        {activeTab === 'scanner' && (
          <div className="space-y-4">
            <div className="bg-surface-900 p-4 rounded-3xl border border-surface-800">
              <h3 className="font-black text-sm text-white">اسکنر هوش مصنوعی غذای ایرانی</h3>
              <span className="text-xs text-slate-400">عکس‌برداری سریع و محاسبه دقیق ماکرو و کالری</span>
            </div>

            {/* Dish selector buttons */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              {Object.keys(IRANIAN_FOODS).map((k) => {
                const dish = IRANIAN_FOODS[k];
                const isAct = selectedDishKey === k;
                return (
                  <button
                    key={k}
                    onClick={() => {
                      soundClick();
                      setSelectedDishKey(k);
                      setScanSuccess(false);
                    }}
                    className={`p-2.5 rounded-2xl text-right transition border flex items-center gap-2 ${
                      isAct ? 'bg-brand-950/40 border-brand-500/60 shadow-md' : 'bg-surface-900 border-surface-800'
                    }`}
                  >
                    <div className="w-2.5 h-2.5 rounded-full bg-brand-400 shrink-0" />
                    <div>
                      <span className="font-bold text-white block text-xs">{dish.title.split(' ')[1] || dish.title}</span>
                      <span className="text-[10px] text-slate-400">{dish.calories} kcal</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Viewfinder Camera Simulation */}
            <div className="relative rounded-3xl overflow-hidden border border-surface-750 bg-black h-56 flex flex-col items-center justify-center">
              <img
                src={activeDish.img}
                alt={activeDish.title}
                className="absolute inset-0 w-full h-full object-cover opacity-60"
              />

              {/* Laser Animation during scan */}
              {isScanningFood && (
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-brand-500/40 to-transparent animate-pulse" />
              )}

              {/* Viewfinder brackets */}
              <div className="absolute inset-6 border-2 border-brand-400/50 rounded-2xl pointer-events-none" />

              {!isScanningFood && !scanSuccess && (
                <button
                  onClick={handleStartScan}
                  className="relative z-10 px-5 py-2.5 rounded-2xl bg-brand-500 hover:bg-brand-400 text-slate-950 font-black text-xs shadow-xl flex items-center gap-2 transition"
                >
                  <Camera className="w-4 h-4" />
                  <span>اسکن هوشمند این بشقاب</span>
                </button>
              )}

              {/* Mascot Pac-Man Loading Screen */}
              {isScanningFood && (
                <div className="relative z-10 w-full p-2">
                  <CabbagePacmanLoader text="کلم باشگاهی در حال بلعیدن و هضم دمبل‌ها..." />
                </div>
              )}
            </div>

            {/* Scan Result Card */}
            {scanSuccess && (
              <div className="p-4 rounded-3xl bg-surface-900 border border-emerald-500/40 space-y-3 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-emerald-400 font-bold block">دقت شناسایی: {(activeDish.confidence * 100).toFixed(0)}٪</span>
                    <h4 className="font-black text-sm text-white">{activeDish.title}</h4>
                  </div>
                  <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-xl font-bold">
                    {activeDish.badge}
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-normal">{activeDish.subtitle}</p>

                <div className="grid grid-cols-4 gap-2 text-center text-xs pt-1">
                  <div className="p-2 bg-surface-850 rounded-xl border border-surface-800">
                    <span className="text-[10px] text-slate-400 block">کالری</span>
                    <span className="font-black text-white font-mono">{activeDish.calories}</span>
                  </div>
                  <div className="p-2 bg-surface-850 rounded-xl border border-surface-800">
                    <span className="text-[10px] text-slate-400 block">پروتئین</span>
                    <span className="font-black text-brand-400 font-mono">{activeDish.protein}g</span>
                  </div>
                  <div className="p-2 bg-surface-850 rounded-xl border border-surface-800">
                    <span className="text-[10px] text-slate-400 block">کربوهیدرات</span>
                    <span className="font-black text-amber-400 font-mono">{activeDish.carbs}g</span>
                  </div>
                  <div className="p-2 bg-surface-850 rounded-xl border border-surface-800">
                    <span className="text-[10px] text-slate-400 block">چربی</span>
                    <span className="font-black text-rose-400 font-mono">{activeDish.fat}g</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    soundSuccess();
                    showToast('وعده غذایی در دیتابیس ثبت شد!');
                  }}
                  className="w-full py-2.5 rounded-xl bg-brand-500 hover:bg-brand-400 text-slate-950 font-black text-xs transition"
                >
                  افزودن به دفترچه غذای امروز
                </button>
              </div>
            )}
          </div>
        )}

        {/* ======================= TAB 4: TRAINER MARKETPLACE ======================= */}
        {activeTab === 'trainers' && (
          <div className="space-y-4">
            <div className="bg-surface-900 p-4 rounded-3xl border border-surface-800">
              <h3 className="font-black text-sm text-white">مارکت‌پلیس مربیان رسمی</h3>
              <span className="text-xs text-slate-400">انتخاب مربی اختصاصی، دریافت رژیم و برنامه تخصصی</span>
            </div>

            <div className="space-y-3">
              {TRAINERS_LIST.map((t) => (
                <div key={t.id} className="p-4 bg-surface-900 rounded-3xl border border-surface-800 space-y-3">
                  <div className="flex items-center gap-3">
                    <img src={t.avatar} alt={t.name} className="w-12 h-12 rounded-2xl object-cover border border-surface-700" />
                    <div className="flex-1">
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-black text-sm text-white">{t.name}</h4>
                        {t.verified && <span className="text-brand-400 text-xs">✓</span>}
                      </div>
                      <span className="text-[11px] text-slate-400 block">{t.title}</span>
                      <span className="text-[10px] text-brand-300 font-bold block">{t.specialty}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1 border-t border-surface-850">
                    <div>
                      <span className="text-[10px] text-slate-400 block">شهریه ماهانه</span>
                      <span className="font-black text-white">{t.priceMonthly}</span>
                    </div>
                    <button
                      onClick={() => {
                        soundSuccess();
                        showToast(`درخواست مشاوره برای ${t.name} ارسال شد.`);
                      }}
                      className="px-4 py-2 rounded-xl bg-fire-500 hover:bg-fire-400 text-slate-950 font-black text-xs transition"
                    >
                      دریافت برنامه
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ======================= TAB 5: TRAINER CRM ======================= */}
        {activeTab === 'crm' && (
          <div className="p-4 sm:p-6 space-y-4">
            <div className="bg-surface-900 p-4 rounded-3xl border border-surface-800 flex justify-between items-center">
              <div>
                <h3 className="font-black text-sm text-white">داشبورد مربی (CRM)</h3>
                <span className="text-xs text-slate-400">مدیریت شاگردان و واریزی‌ها</span>
              </div>
              <div className="text-left">
                <span className="text-[10px] text-slate-400 block">درآمد خالص ماهانه</span>
                <span className="text-xs font-black text-brand-400">۳۴,۲۰۰,۰۰۰ تومان</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="bg-surface-900 p-3 rounded-2xl border border-surface-800">
                <span className="text-[10px] text-slate-400 block">شاگردان فعال</span>
                <span className="text-lg font-black text-white">۳۸ نفر</span>
              </div>
              <div className="bg-surface-900 p-3 rounded-2xl border border-surface-800">
                <span className="text-[10px] text-slate-400 block">هشدار کالری</span>
                <span className="text-lg font-black text-rose-400">۲ مورد</span>
              </div>
            </div>

            <div className="bg-surface-900 rounded-3xl border border-surface-800 p-3 space-y-2">
              <span className="text-xs font-bold text-white block">شاگردان زیر ذره‌بین:</span>
              <div className="p-2.5 bg-surface-850 rounded-xl flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-white block">آرمین صالحی</span>
                  <span className="text-[10px] text-brand-400">رعایت کامل رژیم (۱,۷۵۰ kcal)</span>
                </div>
                <button onClick={() => showToast('پیام تشویق ارسال شد')} className="px-2 py-1 bg-surface-800 rounded text-[10px]">
                  پیام
                </button>
              </div>
              <div className="p-2.5 bg-surface-850 rounded-xl flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-white block">رضا محمدی</span>
                  <span className="text-[10px] text-rose-400">۴۲۰ کالری اضافه دریافت کرده</span>
                </div>
                <button
                  onClick={() => showToast('اخطار اضافه مصرف برای رضا ارسال شد')}
                  className="px-2 py-1 bg-rose-500/20 text-rose-300 rounded text-[10px]"
                >
                  اخطار
                </button>
              </div>
            </div>

            {/* Direct Support & Founder Contact Card */}
            <div className="bg-gradient-to-r from-surface-900 to-surface-850 p-4 rounded-3xl border border-brand-500/30 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-black text-white">مدیر توسعه و ارتباط مستقیم: آرمین</span>
                </div>
                <span className="text-[10px] text-brand-400 font-bold">پاسخگویی سریع</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-normal">
                پشتیبانی فنی مربیان، هماهنگی گیت باشگاه و نسخه آزمایشی
              </p>
              <div className="flex flex-wrap items-center gap-2 pt-1 font-mono">
                <a
                  href="tel:09027897840"
                  className="px-3 py-1.5 rounded-xl bg-brand-500 hover:bg-brand-400 text-slate-950 font-black text-[11px] flex items-center gap-1.5 shadow-sm transition"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span dir="ltr">09027897840</span>
                </a>
                <a
                  href="mailto:arminchinip.ai@gmail.com"
                  className="px-3 py-1.5 rounded-xl bg-surface-800 hover:bg-surface-750 text-white font-bold text-[11px] flex items-center gap-1.5 border border-surface-700 transition"
                >
                  <Mail className="w-3.5 h-3.5 text-brand-400" />
                  <span dir="ltr">arminchinip.ai@gmail.com</span>
                </a>
              </div>
            </div>
          </div>
        )}

        {/* ======================= TAB 6: DATABASE ======================= */}
        {activeTab === 'database' && (
          <div className="p-4 sm:p-6 space-y-4">
            <div className="bg-surface-900 p-4 rounded-3xl border border-surface-800">
              <h3 className="font-black text-sm text-white">دیتابیس گسترش‌یافته (Prisma Schema)</h3>
              <span className="text-xs text-slate-400">۸ کاربر فعال · ۵ مربی · ۱۶ حرکت تمرینی با معادل خانگی</span>
            </div>

            <div className="p-4 bg-surface-900 rounded-3xl border border-surface-800 space-y-2.5 text-xs font-mono">
              <div className="text-brand-400 font-bold">// جدول users (نمونه شاگردان)</div>
              <div className="text-slate-300">
                {`[ { id: 1, name: "آرمین", sub: "pro" }, { id: 6, name: "نگین", weight: 58 }, { id: 8, name: "پویا", weight: 95 } ]`}
              </div>

              <div className="text-brand-400 font-bold mt-2">// جدول exercises (پوشش کامل تمام عضلات)</div>
              <div className="text-slate-300">
                {`[ سینه: پرس هالتر + شنا کش | پشت: زیربغل خم + بارفیکس | پا: اسکوات + بلغاری مبل | سرشانه: پرس دمبل + پایک ]`}
              </div>

              <div className="text-brand-400 font-bold mt-2">// جدول hydration_logs</div>
              <div className="text-slate-300">
                {`{ user_id: 1, current_ml: ${waterConsumedMl}, target_ml: 3500, reminder_active: true }`}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-surface-950 text-white flex flex-col justify-between selection:bg-brand-500 selection:text-slate-950 font-sans">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2.5 text-xs font-bold border transition animate-bounce bg-emerald-950/90 text-emerald-200 border-emerald-800">
          <CheckCircle2 className="w-4 h-4" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Top Control Bar: Device Switcher & Theme Selector (Desktop) */}
      {!isNativeMobile && (
        <div className="bg-surface-900/90 backdrop-blur-md border-b border-surface-800 px-4 py-2.5 sticky top-0 z-40">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
            {/* Brand Logo & Presentation Link */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-brand-600 to-emerald-400 flex items-center justify-center text-white font-black text-sm shadow-md">
                  <DumbbellSvg className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-black text-sm text-white">
                    Gym<span className="text-brand-400">Bro</span>
                  </span>
                  <span className="text-[10px] text-slate-400 mr-1.5">شبیه‌ساز سیستم‌عامل</span>
                </div>
              </div>

              <Link
                href="/"
                className="px-3 py-1.5 rounded-xl bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 border border-brand-500/30 text-xs font-bold flex items-center gap-1.5 transition shadow-sm hover:scale-105"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>صفحه معرفی و پرزنتیشن</span>
              </Link>
            </div>

            {/* Device Mode Switcher */}
            <div className="flex items-center gap-1 bg-surface-850 p-1 rounded-2xl border border-surface-800">
              <button
                onClick={() => {
                  soundClick();
                  setDeviceMode('ios');
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  deviceMode === 'ios' ? 'bg-white text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Apple className="w-3.5 h-3.5" /> نسخه iOS (آیفون ۱۶)
              </button>

              <button
                onClick={() => {
                  soundClick();
                  setDeviceMode('android');
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  deviceMode === 'android' ? 'bg-brand-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" /> نسخه Android (پیکسل ۹)
              </button>

              <button
                onClick={() => {
                  soundClick();
                  setDeviceMode('desktop');
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  deviceMode === 'desktop' ? 'bg-surface-750 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" /> تمام‌صفحه دسکتاپ
              </button>
            </div>

            {/* Mascot Button */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setShowDemoLoader(true);
                  setTimeout(() => setShowDemoLoader(false), 2400);
                }}
                className="px-2.5 py-1 rounded-xl bg-surface-800 text-brand-400 hover:bg-surface-750 text-[10px] font-bold border border-surface-700 flex items-center gap-1.5"
              >
                <DumbbellSvg className="w-3.5 h-3.5" color="var(--brand-400)" />
                <span>تست بلعیدن دمبل توسط کلم</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Floating Actions for Mobile Viewport */}
      {isNativeMobile && (
        <div className="fixed top-3 left-3 z-50 flex items-center gap-2 bg-surface-900/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-surface-750 shadow-2xl text-[11px]">
          <Link href="/" className="text-white hover:text-brand-300 font-bold flex items-center gap-1">
            <span className="text-[10px]">معرفی</span>
          </Link>
          <span className="text-surface-700">|</span>
          <button
            onClick={() => {
              setShowDemoLoader(true);
              setTimeout(() => setShowDemoLoader(false), 2400);
            }}
            className="text-brand-400 font-bold flex items-center gap-1 hover:text-brand-300"
          >
            <DumbbellSvg className="w-3 h-3" color="var(--brand-400)" />
            <span className="font-black text-[10px]">کلم</span>
          </button>
        </div>
      )}

      {/* WATER REMINDER MODAL */}
      {showWaterModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-surface-900 border border-surface-800 rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-surface-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
                  <Droplet className="w-4 h-4" />
                </div>
                <h3 className="font-black text-sm text-white">تنظیمات یادآور هوشمند هیدراتاسیون</h3>
              </div>
              <button onClick={() => setShowWaterModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between p-3 bg-surface-850 rounded-2xl border border-surface-800">
                <div>
                  <span className="font-bold text-white block">فعال‌بودن هشدار نوشیدن آب</span>
                  <span className="text-[10px] text-slate-400">هنگام تمرین زنگ هشدار پخش شود</span>
                </div>
                <button
                  onClick={() => setIsWaterReminderOn(!isWaterReminderOn)}
                  className={`w-11 h-6 rounded-full transition p-1 flex items-center ${
                    isWaterReminderOn ? 'bg-blue-600 justify-end' : 'bg-surface-750 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white" />
                </button>
              </div>

              <div className="p-3 bg-surface-850 rounded-2xl border border-surface-800 space-y-2">
                <span className="font-bold text-white block">بازه زمانی یادآوری:</span>
                <div className="grid grid-cols-3 gap-2">
                  {[30, 45, 60].map((mins) => (
                    <button
                      key={mins}
                      onClick={() => setWaterInterval(mins)}
                      className={`py-2 rounded-xl font-bold transition border ${
                        waterInterval === mins ? 'bg-blue-600 text-white border-blue-500' : 'bg-surface-800 text-slate-400 border-surface-750'
                      }`}
                    >
                      هر {mins} دقیقه
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => {
                  soundWaterDrop();
                  showToast('تنظیمات یادآور آب ذخیره شد.');
                  setShowWaterModal(false);
                }}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-2xl text-xs transition"
              >
                تایید و ذخیره
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 1RM CALCULATOR MODAL */}
      {showOneRmModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-surface-900 border border-surface-800 rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-surface-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center">
                  <CalcIcon className="w-4 h-4" />
                </div>
                <h3 className="font-black text-sm text-white">محاسبه حداکثر رکورد جابجایی وزنه (1RM)</h3>
              </div>
              <button onClick={() => setShowOneRmModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">وزنه جابجا شده (کیلوگرم):</label>
                <input
                  type="number"
                  value={weightInput}
                  onChange={(e) => setWeightInput(Number(e.target.value))}
                  className="w-full bg-surface-850 border border-surface-750 rounded-xl p-2.5 text-white font-mono text-center"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">تعداد تکرار کامل ست (۱ الی ۱۲):</label>
                <input
                  type="number"
                  value={repsInput}
                  onChange={(e) => setRepsInput(Number(e.target.value))}
                  className="w-full bg-surface-850 border border-surface-750 rounded-xl p-2.5 text-white font-mono text-center"
                />
              </div>

              <div className="p-4 bg-surface-850 rounded-2xl border border-surface-800 text-center space-y-1">
                <span className="text-[11px] text-slate-400 block">حداکثر توان ۱ تکرار (فرمول Brzycki):</span>
                <span className="text-2xl font-black text-brand-400 font-mono">{calculated1Rm} کیلوگرم</span>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={calculateOneRm}
                className="flex-1 py-3 bg-brand-500 hover:bg-brand-400 text-slate-950 font-black rounded-2xl text-xs transition"
              >
                محاسبه مجدد
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DEMO CABBAGE LOADER MODAL */}
      {showDemoLoader && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-sm w-full bg-surface-900 border border-surface-750 rounded-3xl p-6">
            <CabbagePacmanLoader text="کلم ورزشی در حال جویدن و بلعیدن دمبل‌ها!" />
          </div>
        </div>
      )}

      {/* MAIN SIMULATOR CANVAS: iOS / Android / Desktop */}
      <div className={isNativeMobile ? 'w-full h-full min-h-[100dvh] flex flex-col p-0 m-0' : 'flex-1 flex items-center justify-center p-2 sm:p-6'}>
        {/* 1. iOS PHONE FRAME */}
        {deviceMode === 'ios' && (
          <div
            className={
              isNativeMobile
                ? 'w-full h-[100dvh] min-h-[100dvh] bg-surface-950 flex flex-col overflow-hidden relative'
                : 'w-full max-w-[400px] h-[840px] bg-black rounded-[52px] border-[10px] border-slate-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden relative transition-all duration-300'
            }
          >
            {/* Dynamic Island */}
            {!isNativeMobile ? (
              <div className="h-9 bg-black flex items-center justify-between px-7 shrink-0 z-30">
                <span className="text-[12px] font-bold text-white tracking-tight">۱۹:۴۲</span>
                <div className="w-24 h-6 bg-slate-950 rounded-full border border-slate-900 flex items-center justify-center gap-2 px-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-brand-500 animate-pulse" />
                  <span className="text-[9px] text-brand-400 font-bold">GymBro</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">۵G 🔋</span>
              </div>
            ) : (
              <div className="shrink-0 z-30 w-full" style={{ paddingTop: 'max(env(safe-area-inset-top, 0px), 14px)' }} />
            )}

            {/* Screen Content */}
            {renderScreenContent()}

            {/* Cupertino Glassmorphism Bottom Tab Bar */}
            <div
              className="absolute bottom-0 inset-x-0 bg-surface-900/90 backdrop-blur-xl border-t border-white/10 px-3 py-2 flex items-center justify-around z-30"
              style={{ paddingBottom: isNativeMobile ? 'max(env(safe-area-inset-bottom, 0px), 16px)' : '8px' }}
            >
              {[
                { id: 'dashboard', label: 'داشبورد', icon: LayoutDashboard },
                { id: 'workout', label: 'تمرین', icon: Flame },
                { id: 'scanner', label: 'اسکنر غذا', icon: ScanLine },
                { id: 'trainers', label: 'مربی‌ها', icon: Users },
                { id: 'crm', label: 'CRM', icon: Briefcase },
              ].map((tab) => {
                const isAct = activeTab === tab.id;
                const IconComponent = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => {
                      soundClick();
                      setActiveTab(tab.id as typeof activeTab);
                    }}
                    className={`flex flex-col items-center gap-0.5 transition ${isAct ? 'text-brand-400' : 'text-slate-400 hover:text-white'}`}
                  >
                    <IconComponent className={`w-5 h-5 ${isAct ? 'stroke-[2.5]' : 'stroke-2'}`} />
                    <span className="text-[10px] font-medium">{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Home Indicator */}
            {!isNativeMobile && (
              <div className="absolute bottom-1 inset-x-0 flex justify-center pointer-events-none z-40">
                <div className="w-32 h-1 bg-white/40 rounded-full" />
              </div>
            )}
          </div>
        )}

        {/* 2. ANDROID PHONE FRAME */}
        {deviceMode === 'android' && (
          <div className="w-full max-w-[400px] h-[840px] bg-surface-950 rounded-[40px] border-[8px] border-slate-750 shadow-2xl flex flex-col overflow-hidden relative transition-all duration-300">
            {/* Punch Hole Camera */}
            <div className="h-8 bg-surface-950 flex items-center justify-between px-6 shrink-0 z-30">
              <span className="text-[11px] font-bold text-slate-300">۱۹:۴۲</span>
              <div className="w-3.5 h-3.5 rounded-full bg-slate-900 border border-slate-800" />
              <span className="text-[10px] text-slate-400 font-mono">LTE 85%</span>
            </div>

            {/* Screen Content */}
            {renderScreenContent()}

            {/* Material 3 Bottom Nav */}
            <div className="absolute bottom-0 inset-x-0 bg-surface-900 border-t border-surface-800 px-2 py-2 flex items-center justify-around z-30">
              {[
                { id: 'dashboard', label: 'داشبورد', icon: LayoutDashboard },
                { id: 'workout', label: 'برنامه', icon: Flame },
                { id: 'scanner', label: 'اسکنر', icon: ScanLine },
                { id: 'trainers', label: 'مربی‌ها', icon: Users },
                { id: 'crm', label: 'CRM', icon: Briefcase },
              ].map((tab) => {
                const isAct = activeTab === tab.id;
                const IconComponent = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => {
                      soundClick();
                      setActiveTab(tab.id as typeof activeTab);
                    }}
                    className="flex flex-col items-center gap-1 transition"
                  >
                    <div className={`px-4 py-1 rounded-full transition ${isAct ? 'bg-brand-500/25 text-brand-400' : 'text-slate-400'}`}>
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <span className={`text-[10px] font-medium ${isAct ? 'text-brand-400 font-bold' : 'text-slate-400'}`}>{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 3. DESKTOP EXPANDED MODE */}
        {deviceMode === 'desktop' && (
          <div className="w-full max-w-5xl bg-surface-900 rounded-3xl border border-surface-800 shadow-2xl overflow-hidden flex flex-col">
            <div className="bg-surface-850 px-6 py-3 border-b border-surface-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {[
                  { id: 'dashboard', label: 'داشبورد ورزشکار', icon: LayoutDashboard },
                  { id: 'workout', label: 'برنامه تمرینی', icon: Flame },
                  { id: 'scanner', label: 'اسکنر هوشمند غذا', icon: ScanLine },
                  { id: 'trainers', label: 'مارکت‌پلیس مربیان', icon: Users },
                  { id: 'crm', label: 'پنل مربی (CRM)', icon: Briefcase },
                  { id: 'database', label: 'دیتابیس زنده', icon: Database },
                ].map((tab) => {
                  const IconComponent = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => {
                        soundClick();
                        setActiveTab(tab.id as typeof activeTab);
                      }}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                        activeTab === tab.id ? 'bg-brand-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white hover:bg-surface-800'
                      }`}
                    >
                      <IconComponent className="w-4 h-4" /> {tab.label}
                    </button>
                  );
                })}
              </div>

              <span className="text-xs text-slate-400 font-semibold">حالت دسکتاپ</span>
            </div>

            <div className="p-4 sm:p-6 max-h-[750px] overflow-y-auto">{renderScreenContent()}</div>
          </div>
        )}
      </div>

      {/* PROFESSIONAL DESKTOP & LANDING FOOTER */}
      {!isNativeMobile && (
        <footer className="w-full bg-surface-950 border-t border-surface-800 py-8 px-4 mt-auto">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-slate-400">
            {/* Brand & Mission */}
            <div className="flex items-center gap-3 text-right">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-brand-600 to-emerald-400 p-0.5 shadow-md flex items-center justify-center">
                <div className="w-full h-full bg-surface-950 rounded-[14px] flex items-center justify-center text-brand-400">
                  <DumbbellSvg className="w-5 h-5" color="var(--brand-400)" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-sm text-white">
                    Gym<span className="text-brand-400">Bro</span>
                  </span>
                  <span className="text-[10px] text-brand-400 font-mono bg-brand-500/10 px-2 py-0.5 rounded-full border border-brand-500/20">
                    v2.4 Production
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  اکوسیستم یکپارچه بدنسازی ایران — پیوند هوشمند ورزشکار، مربی و باشگاه
                </p>
              </div>
            </div>

            {/* Direct Contact with Armin */}
            <div className="flex flex-wrap items-center gap-3 font-mono">
              <a
                href="tel:09027897840"
                className="px-4 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-400 text-slate-950 font-black flex items-center gap-2 transition shadow-md hover:scale-105"
              >
                <Phone className="w-4 h-4" />
                <span dir="ltr">09027897840</span>
              </a>
              <a
                href="mailto:arminchinip.ai@gmail.com"
                className="px-4 py-2.5 rounded-xl bg-surface-850 hover:bg-surface-800 text-white font-bold flex items-center gap-2 transition border border-surface-750 hover:scale-105"
              >
                <Mail className="w-4 h-4 text-brand-400" />
                <span dir="ltr">arminchinip.ai@gmail.com</span>
              </a>
            </div>

            {/* Quick Links */}
            <div className="flex items-center gap-4 text-slate-400 font-medium">
              <Link href="/" className="text-brand-400 hover:underline flex items-center gap-1 font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                پرزنتیشن مربیان
              </Link>
              <span className="text-surface-700">|</span>
              <a href="https://gymbros.ir" target="_blank" rel="noreferrer" className="hover:text-white transition">
                gymbros.ir
              </a>
              <span className="text-surface-700">|</span>
              <a href="https://gymbroapp.ir" target="_blank" rel="noreferrer" className="hover:text-white transition">
                gymbroapp.ir
              </a>
            </div>
          </div>

          <div className="max-w-6xl mx-auto mt-6 pt-4 border-t border-surface-900 flex flex-wrap items-center justify-between text-[11px] text-slate-500">
            <span>مدیر توسعه و ارتباط با باشگاه‌ها: آرمین | کلیه حقوق متعلق به اکوسیستم جیم‌برو است.</span>
            <span className="font-mono">تهران، ایران © ۲۰۲۶</span>
          </div>
        </footer>
      )}
    </div>
  );
};
