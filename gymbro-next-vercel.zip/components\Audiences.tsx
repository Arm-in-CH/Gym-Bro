'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  User,
  Award,
  Building2,
  Sparkles,
  Camera,
  RefreshCw,
  Timer,
  Gamepad2,
  ArrowLeft,
  ChevronLeft,
  Flame,
  CheckCircle2,
  FileSpreadsheet,
  Send,
  CreditCard,
  QrCode,
  ShieldCheck,
  Coffee,
  Database,
  BarChart3,
} from 'lucide-react';
import { soundTab, soundClick } from '@/lib/audio';

interface AudiencesProps {
  onOpenMascotDemo: () => void;
}

export const Audiences: React.FC<AudiencesProps> = ({ onOpenMascotDemo }) => {
  const [activeAudience, setActiveAudience] = useState<'athlete' | 'trainer' | 'gym'>('athlete');

  const handleTabSwitch = (key: 'athlete' | 'trainer' | 'gym') => {
    soundTab();
    setActiveAudience(key);
  };

  return (
    <section id="audiences" className="py-24 bg-surface-900/50 border-y border-surface-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <span className="text-xs font-extrabold uppercase tracking-wider text-brand-400 bg-brand-500/10 px-3.5 py-1 rounded-full border border-brand-500/20">
            طراحی ۳ بعدی برای نیازهای واقعی
          </span>
          <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight">GymBro برای چه کسانی معجزه می‌کند؟</h2>
          <p className="text-slate-400 text-sm sm:text-base">
            بر خلاف اپلیکیشن‌های سنتی که فقط برای ورزشکار طراحی شده‌اند، GymBro یک مثلث ارزش‌آفرینی کامل بین ورزشکار، مربی و باشگاه ایجاد کرده است.
          </p>

          {/* Interactive Audience Tab Buttons */}
          <div className="flex flex-wrap sm:inline-flex justify-center p-1.5 rounded-2xl bg-surface-850 border border-surface-750 gap-1.5 shadow-xl mt-4 max-w-full">
            <button
              onClick={() => handleTabSwitch('athlete')}
              className={`px-3.5 sm:px-5 py-2.5 sm:py-3 rounded-xl text-[11px] sm:text-xs md:text-sm font-black transition flex items-center justify-center gap-1.5 sm:gap-2 ${
                activeAudience === 'athlete' ? 'bg-brand-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <User className="w-4 h-4" />
              <span>۱. ورزشکاران و کاربران</span>
            </button>

            <button
              onClick={() => handleTabSwitch('trainer')}
              className={`px-3.5 sm:px-5 py-2.5 sm:py-3 rounded-xl text-[11px] sm:text-xs md:text-sm font-black transition flex items-center justify-center gap-1.5 sm:gap-2 ${
                activeAudience === 'trainer' ? 'bg-fire-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>۲. مربیان و بدنسازان</span>
            </button>

            <button
              onClick={() => handleTabSwitch('gym')}
              className={`px-3.5 sm:px-5 py-2.5 sm:py-3 rounded-xl text-[11px] sm:text-xs md:text-sm font-black transition flex items-center justify-center gap-1.5 sm:gap-2 ${
                activeAudience === 'gym' ? 'bg-cyber-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>۳. باشگاه‌داران و مجموعه‌ها</span>
            </button>
          </div>
        </div>

        {/* === PANE 1: ATHLETE === */}
        {activeAudience === 'athlete' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center transition-all duration-300">
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 text-brand-400 text-xs font-bold border border-brand-500/20">
                <Sparkles className="w-3.5 h-3.5" />
                تجربه کاربری بی‌نقص ورزشکاران در باشگاه و خانه
              </div>
              <h3 className="text-2xl sm:text-4xl font-black text-white leading-tight">
                تمرین حرفه‌ای، رژیم دقیق ایرانی و انگیزه مداوم بدون سردرگمی
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                دیگر نیازی به باز و بسته کردن فایل‌های PDF یا حفظ کردن ست‌ها نیست. با اسکن هوش مصنوعی غذاهای محلی ایران، سوئیچ هوشمند تمرین باشگاه به خانه، و یادآور خودکار هیدراتاسیون، مثل یک قهرمان پیش بروید.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center font-bold">
                    <Camera className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">اسکنر غذای ایرانی (دقت ۹۵٪)</h4>
                  <p className="text-xs text-slate-400 leading-normal">محاسبه آنی کالری و ماکروی قورمه‌سبزی، کباب کوبیده و سنگک با عکس‌برداری سریع دوربین گوشی.</p>
                </div>

                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-fire-500/20 text-fire-400 flex items-center justify-center font-bold">
                    <RefreshCw className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">سوئیچ هوشمند باشگاه ↔ خانه</h4>
                  <p className="text-xs text-slate-400 leading-normal">اگر وقت باشگاه رفتن نبود، با ۱ کلیک حرکات باشگاه به حرکات معادل خانگی با کش و وزن بدن تبدیل می‌شوند.</p>
                </div>

                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
                    <Timer className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">تایمر استراحت و فرمول 1RM</h4>
                  <p className="text-xs text-slate-400 leading-normal">هشدار هوشمند پایان استراحت ست‌ها و محاسبه علمی حداکثر رکورد جابجایی وزنه‌ها (فرمول Brzycki).</p>
                </div>

                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2 hover:border-amber-500/40 transition">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                    <Gamepad2 className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">گیمیفیکیشن و لودر کلم پک‌من</h4>
                  <p className="text-xs text-slate-400 leading-normal">ماسکوت اختصاصی کلم ورزشی که دمبل‌ها را می‌بلعد! کسب سکه با هر تمرین برای دریافت تخفیف مکمل‌ها.</p>
                  <button
                    onClick={() => {
                      soundClick();
                      onOpenMascotDemo();
                    }}
                    className="mt-1 text-[11px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 transition"
                  >
                    <span>مشاهده انیمیشن زنده بلعیدن دمبل توسط کلم</span>
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <Link href="/app" onClick={() => soundClick()} className="inline-flex items-center gap-2 text-xs font-bold text-brand-400 hover:text-brand-300">
                  <span>تست عملی داشبورد ورزشکار در شبیه‌ساز</span>
                  <ArrowLeft className="w-4 h-4" />
                </Link>
              </div>
            </div>

            {/* Right Showcase Box */}
            <div className="lg:col-span-5">
              <div className="glass-card p-6 rounded-3xl border border-brand-500/30 shadow-glow-emerald space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-surface-800">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center font-bold">
                      <Flame className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">برنامه روزانه آرش راد</div>
                      <div className="text-[10px] text-slate-400">مربی: استاد فرزین کریمی</div>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-brand-400 bg-brand-500/10 px-2.5 py-1 rounded-full">هفته ۳ از ۸</span>
                </div>

                <div className="space-y-2.5 text-xs">
                  <div className="p-3 rounded-2xl bg-surface-850 border border-surface-800 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white block">پرس سینه با هالتر</span>
                      <span className="text-[10px] text-slate-400">۴ ست × ۱۰ تکرار • استراحت ۹۰ث</span>
                    </div>
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  </div>

                  <div className="p-3 rounded-2xl bg-surface-850 border border-surface-800 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white block">زیربغل دمبل تک‌خم</span>
                      <span className="text-[10px] text-slate-400">۴ ست × ۱۲ تکرار • استراحت ۶۰ث</span>
                    </div>
                    <span className="text-[10px] bg-brand-500/20 text-brand-300 px-2.5 py-1 rounded-lg font-bold">ست ۳ در جریان</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-surface-850 border border-surface-800 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white block">اسکوات پا با هالتر</span>
                      <span className="text-[10px] text-slate-400">۴ ست × ۱۰ تکرار • وزن رکورد ۹۵kg</span>
                    </div>
                    <span className="text-[10px] text-slate-500">ست بعدی</span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-gradient-to-r from-brand-600/20 to-emerald-500/10 border border-brand-500/30 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[11px] text-brand-300 block">امتیاز کالری مصرفی امروز:</span>
                    <span className="font-mono text-base font-black text-white">۶۸۰ kcal</span>
                  </div>
                  <Link href="/app" onClick={() => soundClick()} className="px-3.5 py-2 rounded-xl bg-brand-500 text-slate-950 font-black text-[11px] hover:bg-brand-400 transition">
                    ورود به تمرین
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* === PANE 2: TRAINER === */}
        {activeAudience === 'trainer' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center transition-all duration-300">
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-fire-500/10 text-fire-400 text-xs font-bold border border-fire-500/20">
                <Award className="w-3.5 h-3.5" />
                تحول کسب‌وکار و درآمدزایی مربیان بدنسازی و فیتنس
              </div>
              <h3 className="text-2xl sm:text-4xl font-black text-white leading-tight">
                با سیستم‌های سنتی خداحافظی کنید؛ پنل مدیریت اختصاصی شاگردان
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                دیگر نیازی نیست نصف روزتان در واتساپ صرف فرستادن ویس و پیگیری فیش کارت‌به‌کارت شود. با GymBro برنامه‌ها را در ۳ دقیقه بسازید و پول شهریه را مستقیم در حساب شتابی خود تحویل بگیرید.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-fire-500/20 text-fire-400 flex items-center justify-center font-bold">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">سازنده هوشمند برنامه (زیر ۳ دقیقه)</h4>
                  <p className="text-xs text-slate-400 leading-normal">استفاده از ۳۰۰+ حرکت با گیف‌های باکیفیت و قالب‌های از پیش‌آماده برای دوره‌های حجم، کات و فیتنس عمومی.</p>
                </div>

                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                    <CreditCard className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">درگاه پرداخت و تسویه اتوماتیک شاپرک</h4>
                  <p className="text-xs text-slate-400 leading-normal">شاگرد با کارت شتاب آنلاین شهریه را پرداخت می‌کند و طبق چرخه پایا به حساب بانکی مربی واریز می‌گردد.</p>
                </div>

                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
                    <Send className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">پیامک خودکار یادآوری سررسید دوره</h4>
                  <p className="text-xs text-slate-400 leading-normal">۳ روز قبل از اتمام برنامه، پیامک لینک تمدید اختصاصی به نام مربی برای شاگرد ارسال می‌شود (افزایش ۳۵٪ تمدید).</p>
                </div>

                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
                    <BarChart3 className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">داشبورد هشدار و تحلیل شاگردان</h4>
                  <p className="text-xs text-slate-400 leading-normal">اگر شاگردی ۲ روز متوالی تمرین نکرد یا در رژیم افت کالری داشت، سیستم به مربی آلارم می‌دهد.</p>
                </div>
              </div>

              <div className="pt-2">
                <a href="#calculator" onClick={() => soundClick()} className="inline-flex items-center gap-2 text-xs font-bold text-fire-400 hover:text-fire-300">
                  <span>محاسبه درآمد ماهانه شما با ۴۰ شاگرد فعال</span>
                  <ArrowLeft className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Right Showcase Box */}
            <div className="lg:col-span-5">
              <div className="glass-card p-6 rounded-3xl border border-fire-500/30 shadow-glow-orange space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-surface-800">
                  <div>
                    <h4 className="text-sm font-black text-white">پنل مربی (CRM زنده)</h4>
                    <span className="text-[11px] text-slate-400">۴۸ شاگرد فعال • درآمد این ماه: ۶۷.۲ م تومان</span>
                  </div>
                  <span className="text-xs font-bold text-fire-400 bg-fire-500/10 px-2.5 py-1 rounded-full">تایید شده (Verified)</span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3 rounded-2xl bg-surface-850 border border-surface-800 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white">سهراب مرادی (دوره حجم خشک)</span>
                      <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded">تمدید شد (۱.۵ م ت)</span>
                    </div>
                    <p className="text-[11px] text-slate-400">پایبندی: ۹۴٪ • ۳ روز تا پایان دوره</p>
                  </div>

                  <div className="p-3 rounded-2xl bg-surface-850 border border-surface-800 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white">نگین خسروی (چربی‌سوزی پیشرفته)</span>
                      <span className="text-[10px] text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded">نیازمند بازبینی</span>
                    </div>
                    <p className="text-[11px] text-slate-400">هشدار: کالری دیروز ۴۰۰ واحد کمتر از برنامه هدف بوده است.</p>
                  </div>

                  <div className="p-3 rounded-2xl bg-surface-850 border border-surface-800 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white">پویا افشار (برنامه بدنسازی مبتدی)</span>
                      <span className="text-[10px] text-slate-400 font-bold bg-surface-800 px-2 py-0.5 rounded">پیامک تمدید ارسال شد</span>
                    </div>
                    <p className="text-[11px] text-slate-400">تاریخ ثبت نام: ۲۸ روز پیش</p>
                  </div>
                </div>

                <div className="pt-2">
                  <Link href="/app" onClick={() => soundClick()} className="w-full py-3 rounded-xl bg-fire-500 hover:bg-fire-400 text-slate-950 font-black text-xs text-center block transition">
                    ورود به پیش‌نمایش پنل مربی (CRM)
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* === PANE 3: GYM === */}
        {activeAudience === 'gym' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center transition-all duration-300">
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyber-500/10 text-cyber-500 text-xs font-bold border border-cyber-500/20">
                <Building2 className="w-3.5 h-3.5" />
                راهکار ابری یکپارچه برای مدیران باشگاه‌ها و مجموعه‌ها
              </div>
              <h3 className="text-2xl sm:text-4xl font-black text-white leading-tight">
                اتصال گیت‌های تردد، بوفه، کمدها و حسابداری به یک سیستم متمرکز
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                فرار از نرم‌افزارهای دسکتاپ قدیمی و قفل‌های سخت‌افزاری که با هر نوسان برق خراب می‌شوند. با پلتفرم ابری GymBro سالن ورزشی خود را از هر نقطه‌ای روی موبایل مانیتور و مدیریت کنید.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
                    <QrCode className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">اتصال به انواع گیت‌های تردد (RFID و چهره)</h4>
                  <p className="text-xs text-slate-400 leading-normal">همگام‌سازی لحظه‌ای با گیت‌های ورود و خروج؛ جلوگیری از تردد اعضای بدون شهریه یا تاریخ‌گذشته.</p>
                </div>

                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">مدیریت هوشمند کمدهای الکترونیکی</h4>
                  <p className="text-xs text-slate-400 leading-normal">تخصیص اتوماتیک شماره کمد به محض عبور از گیت و بازگشایی امن با مچ‌بند یا اپلیکیشن موبایل.</p>
                </div>

                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                    <Coffee className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">حسابداری و ثبت سفارش آنلاین بوفه</h4>
                  <p className="text-xs text-slate-400 leading-normal">سفارش شیک پروتئینی و مکمل از داخل اپ توسط ورزشکار و تسویه آنی متصل به حساب کمد سالن.</p>
                </div>

                <div className="p-4 rounded-2xl bg-surface-850/80 border border-surface-800 space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
                    <Database className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">پشتیبان‌گیری ابری و امنیت ۱۰۰٪ اطلاعات</h4>
                  <p className="text-xs text-slate-400 leading-normal">دیتابیس ابری با بک‌آپ روزانه؛ بدون هیچ نگرانی از سوختن هارد کامپیوتر منشی باشگاه یا گم شدن پرونده‌ها.</p>
                </div>
              </div>

              <div className="pt-2">
                <a href="#pricing" onClick={() => soundClick()} className="inline-flex items-center gap-2 text-xs font-bold text-cyber-500 hover:text-purple-300">
                  <span>مشاهده پلن اختصاصی باشگاه ابری (Gym Cloud)</span>
                  <ArrowLeft className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Right Showcase Box */}
            <div className="lg:col-span-5">
              <div className="glass-card p-6 rounded-3xl border border-cyber-500/30 shadow-glow-purple space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-surface-800">
                  <div>
                    <h4 className="text-sm font-black text-white">مانیتورینگ زنده سالن ورزشی</h4>
                    <span className="text-[11px] text-slate-400">مجموعه بدنسازی اکسیژن پرو • گیت‌های فعال: ۳</span>
                  </div>
                  <span className="text-xs font-bold text-emerald-400 font-mono">آنلاین</span>
                </div>

                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="p-3 bg-surface-850 rounded-2xl border border-surface-800">
                    <span className="text-[10px] text-slate-400 block">ورزشکاران حاضر در سالن</span>
                    <span className="text-2xl font-black text-white font-mono">۷۴ نفر</span>
                  </div>
                  <div className="p-3 bg-surface-850 rounded-2xl border border-surface-800">
                    <span className="text-[10px] text-slate-400 block">کمدهای خالی</span>
                    <span className="text-2xl font-black text-brand-400 font-mono">۴۶ از ۱۲۰</span>
                  </div>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="p-2.5 bg-surface-850 rounded-xl flex items-center justify-between">
                    <span className="font-bold text-white">تردد اخیر: احسان شمس (کارت طلایی)</span>
                    <span className="text-emerald-400 text-[10px]">ورود موفق • گیت ۱</span>
                  </div>
                  <div className="p-2.5 bg-surface-850 rounded-xl flex items-center justify-between">
                    <span className="font-bold text-white">سفارش بوفه: پروتئین وی کاله + موز</span>
                    <span className="text-blue-400 text-[10px]">کمد ۲۸ • ثبت شد</span>
                  </div>
                </div>

                <div className="pt-2">
                  <button onClick={() => soundClick()} className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs text-center transition">
                    درخواست دمو حضوری و اتصال آزمایشی گیت
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
