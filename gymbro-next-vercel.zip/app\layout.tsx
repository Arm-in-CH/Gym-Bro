import type { Metadata, Viewport } from 'next';
import { Vazirmatn } from 'next/font/google';
import './globals.css';

const vazirmatn = Vazirmatn({
  subsets: ['arabic', 'latin'],
  display: 'swap',
  variable: '--font-vazirmatn',
  weight: ['300', '400', '500', '600', '700', '800', '900'],
});

export const metadata: Metadata = {
  title: 'GymBro — پلتفرم جامع اکوسیستم فیتنس، مربیان و باشگاه‌های ورزشی',
  description: 'سوپراپ هوشمند بدنسازی و فیتنس با هوش مصنوعی آنالیز سفره ایرانی، پنل درآمد و مدیریت شاگردان مربی و اتوماسیون ابری باشگاه‌ها.',
  keywords: ['بدنسازی', 'برنامه تمرینی', 'مربی آنلاین', 'کالری شمار ایرانی', 'قرمه سبزی', 'فیتنس', 'جیم برو', 'GymBro'],
  authors: [{ name: 'Armin Chinipardaz - Founder & AI Engineer', url: 'https://gymbro.ir' }],
  creator: 'Armin Chinipardaz',
  manifest: '/manifest.json',
  openGraph: {
    title: 'GymBro — پلتفرم نسل آینده فیتنس و مربیگری هوشمند',
    description: 'تحلیل هوشمند رژیم غذایی سنتی، دفترچه تمرین حرفه‌ای و مدیریت شاگردان با بالاترین بازدهی.',
    locale: 'fa_IR',
    type: 'website',
  },
};

export const viewport: Viewport = {
  themeColor: '#050811',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl" className={`dark scroll-smooth ${vazirmatn.variable}`}>
      <body className={`${vazirmatn.className} selection:bg-brand-500 selection:text-white bg-surface-950 text-slate-100 min-h-screen antialiased`}>
        {children}
      </body>
    </html>
  );
}
