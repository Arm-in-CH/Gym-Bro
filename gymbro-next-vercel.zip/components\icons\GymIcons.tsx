import React from 'react';

interface IconProps {
  className?: string;
  color?: string;
}

export const DumbbellSvg: React.FC<IconProps> = ({ className = 'w-5 h-5', color = 'currentColor' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m6.5 6.5 11 11" />
    <path d="m21 21-1-1" />
    <path d="m3 3 1 1" />
    <path d="m18 22 4-4" />
    <path d="m2 6 4-4" />
    <path d="m3 10 7-7" />
    <path d="m14 21 7-7" />
  </svg>
);

export const KettlebellSvg: React.FC<IconProps> = ({ className = 'w-5 h-5', color = 'currentColor' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M8 9a4 4 0 0 1 8 0" />
    <rect x="5" y="9" width="14" height="12" rx="6" />
    <circle cx="12" cy="15" r="2" />
  </svg>
);

export const ShakerBottleSvg: React.FC<IconProps> = ({ className = 'w-5 h-5', color = 'currentColor' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 2h6v3H9z" />
    <path d="M7 5h10l-1 16H8L7 5z" />
    <path d="M8 10h8" />
    <path d="M8 14h8" />
  </svg>
);
