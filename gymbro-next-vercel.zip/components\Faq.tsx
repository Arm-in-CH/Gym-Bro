'use client';

import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { soundClick } from '@/lib/audio';

interface FaqItem {
  id: number;
  question: string;
  answer: string;
}

const FAQS: FaqItem[] = [
  {
    id: 1,
    question: 'آیا شاگردان و ورزشکاران برای استفاده از اپلیکیشن نیاز به فیلترشکن دارند؟',
    answer:
      'خیر؛ زیرساخت سرورها بر بستر سرورهای داخلی ابری مستقر شده است و تمامی خدمات شامل ورود، ثبت تمرین، اسکن غذا و پرداخت اینترنتی بدون نیاز به فیلترشکن و با نهایت سرعت باز می‌شوند.',
  },
  {
    id: 2,
    question: 'نسخه iOS برای کاربران آیفون چگونه نصب می‌شود؟',
    answer:
      'جیم‌برو به صورت یک اپلیکیشن تحت وب پیشرفته (PWA Standalone) مهندسی شده است. کاربران آیفون با زدن دکمه Share در مرورگر Safari و انتخاب Add to Home Screen (افزودن به صفحه اصلی) می‌توانند آن را بدون نیاز به سیب‌اپ یا اپ‌استور مستقیماً مثل یک اپلیکیشن نیتیو باز کنند.',
  },
  {
    id: 3,
    question: 'تسویه حساب مالی مربیان چگونه و در چه بازه‌هایی انجام می‌پذیرد؟',
    answer:
      'شهریه‌های واریزی توسط شاگردان به صورت خودکار از طریق درگاه‌های شاپرکی دریافت شده و طبق چرخه رسمی پایا به صورت روزانه مستقیم به شماره شبای مربی واریز می‌گردد؛ همراه با گزارش دقیق نام شاگرد و نوع برنامه.',
  },
  {
    id: 4,
    question: 'آیا باشگاه‌ها می‌توانند از گیت‌ها و دستگاه‌های حضور و غیاب فعلی خود استفاده کنند؟',
    answer:
      'بله، API ماژول سخت‌افزاری GymBro با پروتکل‌های رایج Wiegand و شبکه LAN سازگار است و به اکثر برندهای معتبر گیت و کنترل دسترسی بازار ایران متصل می‌شود.',
  },
];

export const Faq: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const toggleFaq = (id: number) => {
    soundClick();
    setOpenFaq(openFaq === id ? null : id);
  };

  return (
    <section id="faq" className="py-24 bg-surface-900/40 border-t border-surface-800">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-14">
          <span className="text-xs font-extrabold uppercase tracking-wider text-brand-400 bg-brand-500/10 px-3.5 py-1 rounded-full border border-brand-500/20">
            پاسخ به ابهامات
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">سوالات متداول مربیان، باشگاه‌ها و ورزشکاران</h2>
        </div>

        <div className="space-y-4">
          {FAQS.map((faq) => {
            const isOpen = openFaq === faq.id;
            return (
              <div key={faq.id} className="p-5 rounded-2xl bg-surface-850/80 border border-surface-800 transition">
                <button onClick={() => toggleFaq(faq.id)} className="w-full flex items-center justify-between text-right text-sm font-bold text-white">
                  <span>{faq.question}</span>
                  <ChevronDown className={`w-4 h-4 text-brand-400 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
                </button>
                {isOpen && (
                  <div className="pt-3 text-xs text-slate-300 leading-relaxed border-t border-surface-800 mt-3 animate-fadeIn">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
