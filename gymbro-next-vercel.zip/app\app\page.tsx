'use client';

import React from 'react';
import { SimulatorCanvas } from '@/components/simulator/SimulatorCanvas';

export default function SimulatorPage() {
  return <SimulatorCanvas />;
}
