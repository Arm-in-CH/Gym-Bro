import { NextResponse } from 'next/server';
import { TRAINERS_LIST } from '@/lib/data';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get('q')?.toLowerCase();
  const specialty = searchParams.get('specialty')?.toLowerCase();

  let results = [...TRAINERS_LIST];

  if (query) {
    results = results.filter(
      (t) =>
        t.name.toLowerCase().includes(query) ||
        t.title.toLowerCase().includes(query) ||
        t.specialty.toLowerCase().includes(query)
    );
  }

  if (specialty) {
    results = results.filter((t) =>
      t.specialty.toLowerCase().includes(specialty)
    );
  }

  return NextResponse.json({
    success: true,
    total: results.length,
    trainers: results,
  });
}
