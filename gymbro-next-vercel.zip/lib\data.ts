export interface FoodItem {
  id: string;
  title: string;
  subtitle: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  confidence: number;
  badge: string;
  img: string;
}

export const IRANIAN_FOODS: Record<string, FoodItem> = {
  koobideh: {
    id: 'koobideh',
    title: 'چلو کباب کوبیده زعفرانی (۲ سیخ)',
    subtitle: '۳۰۰ گرم برنج زعفرانی + ۲۴۰ گرم گوشت گوسفند و پیاز',
    calories: 780,
    protein: 42,
    carbs: 68,
    fat: 34,
    confidence: 0.96,
    badge: 'پرچرب و پروتئینی',
    img: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop&q=80',
  },
  ghormeh: {
    id: 'ghormeh',
    title: 'چلو قورمه‌سبزی جاافتاده با گوشت گوساله',
    subtitle: '۲۵۰ گرم کته ایرانی + خورشت سبزی سرخ‌شده با لیموعمانی',
    calories: 620,
    protein: 36,
    carbs: 62,
    fat: 22,
    confidence: 0.94,
    badge: 'پروتئین باکیفیت',
    img: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80',
  },
  joojeh: {
    id: 'joojeh',
    title: 'چلو جوجه‌کباب سینه مرغ زعفرانی',
    subtitle: '۳۰۰ گرم سینه مرغ گریل بدون دنبه + برنج کته رژیمی',
    calories: 520,
    protein: 54,
    carbs: 58,
    fat: 8,
    confidence: 0.98,
    badge: 'انتخاب طلایی کات',
    img: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80',
  },
  gheimeh: {
    id: 'gheimeh',
    title: 'چلو قیمه سیب‌زمینی سنتی',
    subtitle: 'خورشت لپه، لیموعمانی، گوشت مغز ران + سیب‌زمینی خلال ترد',
    calories: 640,
    protein: 32,
    carbs: 70,
    fat: 24,
    confidence: 0.91,
    badge: 'انرژی‌بخش قبل تمرین',
    img: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=800&auto=format&fit=crop&q=80',
  },
};

export interface Trainer {
  id: number;
  name: string;
  title: string;
  specialty: string;
  rating: number;
  reviewsCount: number;
  studentsCount: number;
  priceMonthly: string;
  verified: boolean;
  avatar: string;
}

export const TRAINERS_LIST: Trainer[] = [
  {
    id: 1,
    name: 'استاد فرزین کریمی',
    title: 'مربی رسمی فدراسیون IFBB · قهرمان کشور',
    specialty: 'حجم خشک و کات حرفه‌ای',
    rating: 4.9,
    reviewsCount: 124,
    studentsCount: 48,
    priceMonthly: '۱,۴۰۰,۰۰۰ تومان',
    verified: true,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
  },
  {
    id: 2,
    name: 'دکتر مونا رادفر',
    title: 'متخصص تغذیه ورزشی · فیزیولوژی تمرین',
    specialty: 'اصلاح فرم، بانوان و لاغری ایمن',
    rating: 5.0,
    reviewsCount: 96,
    studentsCount: 62,
    priceMonthly: '۱,۸۰۰,۰۰۰ تومان',
    verified: true,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
  },
  {
    id: 3,
    name: 'سهراب نامدار',
    title: 'مربی کراس‌فیت و آماده‌سازی توان جسمانی',
    specialty: 'استقامت قلبی عروقی و کتل‌بل',
    rating: 4.8,
    reviewsCount: 58,
    studentsCount: 31,
    priceMonthly: '۹۵۰,۰۰۰ تومان',
    verified: false,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
  },
];

export interface ExerciseItem {
  id: string;
  name: string;
  muscle: string;
  gymVersion: string;
  homeVersion: string;
  sets: number;
  reps: string;
  restSec: number;
  rpe: number;
}

export const TODAY_WORKOUT: ExerciseItem[] = [
  {
    id: 'e1',
    name: 'پرس سینه هالتر',
    muscle: 'سینه (میانی و فوقانی)',
    gymVersion: 'پرس سینه هالتر روی نیمکت مسطح (۴ ست ۱۰ تکرار)',
    homeVersion: 'شنا سوئدی پیشرفته با مقاومت کش پاورباند روی شانه',
    sets: 4,
    reps: '10-12',
    restSec: 90,
    rpe: 8,
  },
  {
    id: 'e2',
    name: 'زیربغل دمبل تک خم',
    muscle: 'پشت و زیربغل (لاتیسیموس)',
    gymVersion: 'زیربغل دمبل تک خم تکیه بر میز (۴ ست ۱۲ تکرار)',
    homeVersion: 'قایقی نشسته با کش لوپ متصل به درب اتاق',
    sets: 4,
    reps: '12',
    restSec: 60,
    rpe: 7.5,
  },
  {
    id: 'e3',
    name: 'اسکوات پا',
    muscle: 'چهارسر ران و باسن',
    gymVersion: 'اسکوات پشت با هالتر المپیکی (۴ ست ۱۰ تکرار)',
    homeVersion: 'اسکوات بلغاری تک‌پا تکیه بر لبه مبل راحتی',
    sets: 4,
    reps: '10',
    restSec: 90,
    rpe: 8.5,
  },
  {
    id: 'e4',
    name: 'پرس سرشانه',
    muscle: 'دلتوئید قدامی و میانی',
    gymVersion: 'پرس سرشانه دمبل نشسته زاویه ۷۵ درجه',
    homeVersion: 'شنا پایک شیب‌دار (Pike Pushup) یا پرس کش مقاومتی',
    sets: 3,
    reps: '12',
    restSec: 60,
    rpe: 8,
  },
];
