'use client';

import React from 'react';
import { X } from 'lucide-react';
import { CabbagePacmanLoader } from './simulator/CabbagePacmanLoader';

interface MascotModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MascotModal: React.FC<MascotModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="max-w-md w-full bg-surface-900 border border-surface-750 rounded-3xl p-6 space-y-4 shadow-2xl relative">
        <button onClick={onClose} className="absolute top-4 left-4 text-slate-400 hover:text-white transition">
          <X className="w-5 h-5" />
        </button>

        <div className="text-right space-y-1 pr-1">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <h3 className="text-base font-black text-white">ماسکوت اختصاصی جیم‌برو (کلم ورزشی)</h3>
          </div>
          <p className="text-xs text-slate-400">لودر هوشمند و گیمیفیکیشن بلعیدن دمبل‌ها حین محاسبه تمرینات و کالری</p>
        </div>

        {/* Mascot Animation Box */}
        <CabbagePacmanLoader
          text="کلم در حال بلعیدن و هضم دمبل‌ها!"
          subtext="تبدیل دمبل‌ها به پروتئین خالص و سکه گیمیفیکیشن..."
        />

        <div className="pt-2 flex justify-end">
          <button onClick={onClose} className="px-5 py-2.5 rounded-xl bg-surface-850 hover:bg-surface-800 text-white font-bold text-xs transition">
            بستن پیش‌نمایش
          </button>
        </div>
      </div>
    </div>
  );
};
