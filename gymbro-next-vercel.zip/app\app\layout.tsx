import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'GymBro Simulator — شبیه‌ساز زنده اپلیکیشن و پنل مربیان',
  description: 'تست زنده ماژول‌های اپلیکیشن GymBro: آنالیز هوش مصنوعی غذاهای ایرانی، لاگر تمرین، ماشین‌حساب 1RM و CRM مربیان',
};

export default function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
