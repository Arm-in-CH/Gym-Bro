'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { PlayCircle, Volume2, VolumeX, Menu, X, Phone } from 'lucide-react';
import { soundClick, soundSuccess, isSoundEnabled, setSoundEnabled } from '@/lib/audio';

export const Navbar: React.FC = () => {
  const [soundOn, setSoundOn] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    setSoundEnabled(next);
    if (next) soundClick();
  };

  const handleNavClick = () => {
    soundClick();
    setMobileMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-50 bg-surface-950/80 backdrop-blur-xl border-b border-surface-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Logo & Tagline */}
        <Link href="/" onClick={() => soundClick()} className="flex items-center gap-3 group">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-brand-600 via-brand-500 to-emerald-300 p-0.5 shadow-glow-emerald flex items-center justify-center transition group-hover:scale-105">
            <div className="w-full h-full bg-surface-950 rounded-[14px] flex items-center justify-center">
              <svg className="w-6 h-6 text-brand-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m6.5 6.5 11 11" />
                <path d="m21 21-1-1" />
                <path d="m3 3 1 1" />
                <path d="m18 22 4-4" />
                <path d="m2 6 4-4" />
                <path d="m3 10 7-7" />
                <path d="m14 21 7-7" />
              </svg>
            </div>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-xl font-black tracking-tight text-white">
                Gym<span className="text-brand-400">Bro</span>
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-brand-500/10 text-brand-400 border border-brand-500/20">
                نسخه ۲.۴
              </span>
            </div>
            <span className="text-[11px] text-slate-400 font-medium">سوپراپلیکیشن فیتنس و مدیریت ورزشی</span>
          </div>
        </Link>

        {/* Desktop Nav Links */}
        <div className="hidden md:flex items-center gap-1 bg-surface-900/90 border border-surface-800 p-1 rounded-2xl text-xs font-semibold text-slate-300">
          <a href="#audiences" onClick={handleNavClick} className="px-4 py-2 rounded-xl hover:text-white hover:bg-surface-800 transition">
            ۳ مخاطب پلتفرم
          </a>
          <a href="#calculator" onClick={handleNavClick} className="px-4 py-2 rounded-xl hover:text-white hover:bg-surface-800 transition">
            ماشین‌حساب درآمد
          </a>
          <a href="#comparison" onClick={handleNavClick} className="px-4 py-2 rounded-xl hover:text-white hover:bg-surface-800 transition">
            مقایسه با واتساپ و اکسل
          </a>
          <a href="#pricing" onClick={handleNavClick} className="px-4 py-2 rounded-xl hover:text-white hover:bg-surface-800 transition">
            تعرفه‌ها
          </a>
          <a href="#faq" onClick={handleNavClick} className="px-4 py-2 rounded-xl hover:text-white hover:bg-surface-800 transition">
            سوالات متداول
          </a>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          {/* Live App Launcher Button */}
          <Link
            href="/app"
            onClick={() => soundSuccess()}
            className="px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl bg-gradient-to-r from-brand-600 to-emerald-500 hover:from-brand-500 hover:to-emerald-400 text-white font-bold text-xs shadow-glow-emerald transition flex items-center gap-1.5 sm:gap-2 hover:scale-[1.02]"
          >
            <PlayCircle className="w-4 h-4" />
            <span className="hidden sm:inline">تست آنلاین وب‌اپ (Demo)</span>
            <span className="sm:hidden">دمو آنلاین</span>
          </Link>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-surface-850 hover:bg-surface-800 border border-surface-750 flex items-center justify-center text-slate-400 hover:text-white transition"
            title="افکت‌های صوتی"
          >
            {soundOn ? <Volume2 className="w-4 h-4 text-brand-400" /> : <VolumeX className="w-4 h-4 text-slate-600" />}
          </button>

          {/* Mobile Menu Hamburger Button */}
          <button
            onClick={() => {
              soundClick();
              setMobileMenuOpen(!mobileMenuOpen);
            }}
            className="md:hidden w-9 h-9 rounded-xl bg-surface-850 hover:bg-surface-800 border border-surface-750 flex items-center justify-center text-slate-300 hover:text-white transition"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-surface-900/95 backdrop-blur-xl border-b border-surface-800 px-4 py-4 space-y-2 text-xs font-bold text-slate-300">
          <a href="#audiences" onClick={handleNavClick} className="block p-2.5 rounded-xl hover:bg-surface-800 hover:text-white transition">
            ۳ مخاطب پلتفرم (ورزشکار / مربی / باشگاه)
          </a>
          <a href="#calculator" onClick={handleNavClick} className="block p-2.5 rounded-xl hover:bg-surface-800 hover:text-white transition">
            ماشین‌حساب درآمد مربیان
          </a>
          <a href="#comparison" onClick={handleNavClick} className="block p-2.5 rounded-xl hover:bg-surface-800 hover:text-white transition">
            مقایسه رو در رو (با واتساپ و اکسل)
          </a>
          <a href="#pricing" onClick={handleNavClick} className="block p-2.5 rounded-xl hover:bg-surface-800 hover:text-white transition">
            تعرفه‌ها و اشتراک‌ها
          </a>
          <a href="#faq" onClick={handleNavClick} className="block p-2.5 rounded-xl hover:bg-surface-800 hover:text-white transition">
            سوالات متداول
          </a>
          <div className="pt-2 border-t border-surface-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <a href="tel:09027897840" className="text-brand-400 font-bold flex items-center gap-1">
              <Phone className="w-3.5 h-3.5" /> ۰۹۰۲۷۸۹۷۸۴۰
            </a>
            <a href="mailto:arminchinip.ai@gmail.com" className="hover:text-white">
              ایمیل پشتیبانی
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};
