'use client';

import React from 'react';
import { CheckCircle } from 'lucide-react';

export const ComparisonTable: React.FC = () => {
  return (
    <section id="comparison" className="py-24 bg-surface-900/60 border-t border-surface-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <span className="text-xs font-extrabold uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-3.5 py-1 rounded-full border border-cyan-500/20">
            مقایسه رو در رو
          </span>
          <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight">چرا روش‌های سنتی دیگر جواب نمی‌دهد؟</h2>
          <p className="text-slate-400 text-sm sm:text-base">
            تفاوت کار با GymBro در مقابل روش‌های قدیمی مثل پیام‌های درهم‌ریخته واتساپ، اکسل و کاغذهای چاپی.
          </p>
        </div>

        {/* Comparison Matrix */}
        <div className="max-w-5xl mx-auto overflow-x-auto">
          <table className="w-full text-right text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="border-b border-surface-800 text-slate-400 font-bold">
                <th className="py-4 px-4 w-1/3">قابلیت و امکانات</th>
                <th className="py-4 px-4 w-1/3 text-brand-400 bg-brand-500/10 rounded-t-2xl border-t border-x border-brand-500/20">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-brand-400" />
                    <span>پلتفرم یکپارچه GymBro</span>
                  </div>
                </th>
                <th className="py-4 px-4 w-1/3">روش سنتی (واتساپ / اکسل / کاغذ)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-800/60">
              <tr className="hover:bg-surface-850/30 transition">
                <td className="py-4 px-4 font-bold text-white">زمان ثبت و ارسال برنامه</td>
                <td className="py-4 px-4 bg-brand-500/5 border-x border-brand-500/20 font-bold text-emerald-400">
                  کمتر از ۳ دقیقه با قالب‌های هوشمند
                </td>
                <td className="py-4 px-4 text-slate-400">۳۰ الی ۴۵ دقیقه تایپ دستی یا ویس طولانی</td>
              </tr>

              <tr className="hover:bg-surface-850/30 transition">
                <td className="py-4 px-4 font-bold text-white">ردیابی کالری غذاهای ایرانی</td>
                <td className="py-4 px-4 bg-brand-500/5 border-x border-brand-500/20 font-bold text-emerald-400">
                  اسکن آنی هوش مصنوعی با دیتابیس بومی
                </td>
                <td className="py-4 px-4 text-slate-400">تقریبی یا غیراستاندارد در MyFitnessPal</td>
              </tr>

              <tr className="hover:bg-surface-850/30 transition">
                <td className="py-4 px-4 font-bold text-white">سیستم تمدید شهریه و پرداخت</td>
                <td className="py-4 px-4 bg-brand-500/5 border-x border-brand-500/20 font-bold text-emerald-400">
                  درگاه پرداخت شتاب + پیامک یادآور اتوماتیک
                </td>
                <td className="py-4 px-4 text-slate-400">کارت‌به‌کارت دستی، پیگیری تلفنی و گم‌شدن فیش</td>
              </tr>

              <tr className="hover:bg-surface-850/30 transition">
                <td className="py-4 px-4 font-bold text-white">ورود به باشگاه و گیت تردد</td>
                <td className="py-4 px-4 bg-brand-500/5 border-x border-brand-500/20 font-bold text-emerald-400">
                  اتصال ابری به RFID، تشخیص چهره و کمدها
                </td>
                <td className="py-4 px-4 text-slate-400">دفتر حضور و غیاب دستی یا سیستم‌های آفلاین خراب</td>
              </tr>

              <tr className="hover:bg-surface-850/30 transition">
                <td className="py-4 px-4 font-bold text-white">تبدیل برنامه باشگاه به خانه</td>
                <td className="py-4 px-4 bg-brand-500/5 border-x border-brand-500/20 font-bold text-emerald-400">
                  سوئیچ آنی با ۱ کلیک (حرکات جایگزین کش/وزن بدن)
                </td>
                <td className="py-4 px-4 text-slate-400">ناممکن؛ شاگرد باید دوباره به مربی پیام دهد</td>
              </tr>

              <tr className="hover:bg-surface-850/30 transition">
                <td className="py-4 px-4 font-bold text-white">پایبندی شاگرد و تحلیل پیشرفت</td>
                <td className="py-4 px-4 bg-brand-500/5 border-x border-brand-500/20 font-bold text-emerald-400">
                  داشبورد درصد حضور، رکورد 1RM و عکس محرمانه
                </td>
                <td className="py-4 px-4 text-slate-400">شاگرد رها می‌شود و مربی اطلاعی از پایبندی ندارد</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};
