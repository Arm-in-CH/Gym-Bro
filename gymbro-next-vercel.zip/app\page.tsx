'use client';

import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { Audiences } from '@/components/Audiences';
import { RoiCalculator } from '@/components/RoiCalculator';
import { ComparisonTable } from '@/components/ComparisonTable';
import { Pricing } from '@/components/Pricing';
import { Faq } from '@/components/Faq';
import { Footer } from '@/components/Footer';
import { MascotModal } from '@/components/MascotModal';
import { CoachModal } from '@/components/CoachModal';

export default function LandingPage() {
  const [isCoachModalOpen, setIsCoachModalOpen] = useState(false);
  const [isMascotModalOpen, setIsMascotModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-surface-950 text-slate-100 flex flex-col selection:bg-brand-500 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-emerald-500/95 text-surface-950 font-bold px-6 py-3 rounded-2xl shadow-glow-emerald backdrop-blur-md animate-bounce flex items-center gap-2 border border-emerald-400">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
          </svg>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Navigation */}
      <Navbar />

      {/* Main Content Sections */}
      <main className="flex-1">
        <Hero onOpenCoachModal={() => setIsCoachModalOpen(true)} />
        <Audiences onOpenMascotDemo={() => setIsMascotModalOpen(true)} />
        <RoiCalculator />
        <ComparisonTable />
        <Pricing onOpenCoachModal={() => setIsCoachModalOpen(true)} />
        <Faq />
      </main>

      {/* Global High-Conversion Footer with Founder Contacts */}
      <Footer onOpenCoachModal={() => setIsCoachModalOpen(true)} />

      {/* Interactive Modals */}
      <MascotModal
        isOpen={isMascotModalOpen}
        onClose={() => setIsMascotModalOpen(false)}
      />
      
      <CoachModal
        isOpen={isCoachModalOpen}
        onClose={() => setIsCoachModalOpen(false)}
        onShowToast={showToast}
      />
    </div>
  );
}
