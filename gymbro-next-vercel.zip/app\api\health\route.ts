import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    status: 'healthy',
    platform: 'GymBro SuperApp Next.js',
    version: '2.4.0',
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.floor(process.uptime()),
    region: process.env.VERCEL_REGION || process.env.CF_PAGES || 'edge-serverless',
  });
}
