'use client';

import React, { useState } from 'react';
import { X, Award, CheckCircle2 } from 'lucide-react';
import { soundSuccess } from '@/lib/audio';

interface CoachModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string) => void;
}

export const CoachModal: React.FC<CoachModalProps> = ({ isOpen, onClose, onShowToast }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [role, setRole] = useState('coach');
  const [count, setCount] = useState('10-30');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    soundSuccess();

    const leadData = {
      name,
      phone,
      city,
      role,
      count,
      createdAt: new Date().toISOString(),
    };

    try {
      // Call Next.js Serverless API Route
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(leadData),
      });

      // Also store in localStorage as client fallback
      if (typeof window !== 'undefined') {
        const stored = JSON.parse(localStorage.getItem('gymbro_leads') || '[]');
        stored.push(leadData);
        localStorage.setItem('gymbro_leads', JSON.stringify(stored));
      }
    } catch {
      // Local storage fallback
      if (typeof window !== 'undefined') {
        const stored = JSON.parse(localStorage.getItem('gymbro_leads') || '[]');
        stored.push(leadData);
        localStorage.setItem('gymbro_leads', JSON.stringify(stored));
      }
    }

    setIsSubmitting(false);
    setIsSuccess(true);
    onShowToast('اطلاعات مربی با موفقیت ثبت شد!');

    setTimeout(() => {
      setIsSuccess(false);
      setName('');
      setPhone('');
      setCity('');
      onClose();
    }, 2400);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="max-w-lg w-full bg-surface-900 border border-surface-750 rounded-3xl p-6 sm:p-8 space-y-5 shadow-2xl relative">
        {/* Close Button */}
        <button onClick={onClose} className="absolute top-5 left-5 text-slate-400 hover:text-white transition">
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 border-b border-surface-800 pb-4">
          <div className="w-12 h-12 rounded-2xl bg-fire-500/20 text-fire-400 flex items-center justify-center shrink-0">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white">دریافت پنل اختصاصی مربی و باشگاه</h3>
            <p className="text-xs text-slate-400">۱۴ روز دسترسی تست رایگان + راهنمای راه‌اندازی فوری</p>
          </div>
        </div>

        {/* Lead Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-bold mb-1.5">نام و نام خانوادگی:</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثال: آرش کیانی"
              className="w-full bg-surface-850 border border-surface-750 rounded-xl p-3 text-white focus:border-brand-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-bold mb-1.5">شماره همراه (جهت دریافت پنل):</label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="۰۹۱۲..."
                className="w-full bg-surface-850 border border-surface-750 rounded-xl p-3 text-white focus:border-brand-500 focus:outline-none font-mono text-center"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-bold mb-1.5">شهر / استان:</label>
              <input
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="تهران، اصفهان، مشهد..."
                className="w-full bg-surface-850 border border-surface-750 rounded-xl p-3 text-white focus:border-brand-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-bold mb-1.5">نقش شما:</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full bg-surface-850 border border-surface-750 rounded-xl p-3 text-white focus:border-brand-500 focus:outline-none"
              >
                <option value="coach">مربی بدنسازی و فیتنس</option>
                <option value="dietitian">متخصص تغذیه ورزشی</option>
                <option value="gym_owner">مدیر یا موسس باشگاه</option>
                <option value="champion">قهرمان و ورزشکار حرفه‌ای</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-bold mb-1.5">تعداد شاگردان فعال:</label>
              <select
                value={count}
                onChange={(e) => setCount(e.target.value)}
                className="w-full bg-surface-850 border border-surface-750 rounded-xl p-3 text-white focus:border-brand-500 focus:outline-none font-mono"
              >
                <option value="10-30">۱۰ الی ۳۰ شاگرد</option>
                <option value="30-80">۳۰ الی ۸۰ شاگرد</option>
                <option value="80+">بیش از ۸۰ شاگرد</option>
                <option value="gym">باشگاه (بیش از ۲۰۰ عضو)</option>
              </select>
            </div>
          </div>

          {isSuccess && (
            <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-center font-bold animate-fadeIn">
              درخواست شما ثبت شد! اطلاعات ورود موقت پیامک خواهد شد.
            </div>
          )}

          {!isSuccess && (
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 bg-gradient-to-r from-fire-600 to-amber-500 hover:from-fire-500 hover:to-amber-400 text-white font-black rounded-2xl text-xs shadow-glow-orange transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'در حال ارسال اطلاعات...' : 'ثبت و فعال‌سازی فوری پنل'}</span>
            </button>
          )}
        </form>
      </div>
    </div>
  );
};
