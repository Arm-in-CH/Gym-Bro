import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-vazirmatn)", "Vazirmatn", "system-ui", "sans-serif"],
      },
      colors: {
        brand: {
          50: "#ecfdf5",
          100: "#d1fae5",
          400: "#34d399",
          500: "#10b981",
          600: "#059669",
          700: "#047857",
        },
        cyber: {
          500: "#8b5cf6",
          600: "#7c3aed",
        },
        fire: {
          500: "#f97316",
          600: "#ea580c",
        },
        surface: {
          950: "#050811",
          900: "#0c1120",
          850: "#131a30",
          800: "#1c2542",
          750: "#27345b",
          700: "#384b73",
        },
      },
      boxShadow: {
        "glow-emerald": "0 0 50px -10px rgba(16, 185, 129, 0.35)",
        "glow-cyan": "0 0 50px -10px rgba(6, 182, 212, 0.35)",
        "glow-orange": "0 0 50px -10px rgba(249, 115, 22, 0.35)",
        "glow-purple": "0 0 50px -10px rgba(139, 92, 246, 0.35)",
      },
    },
  },
  plugins: [],
};

export default config;
