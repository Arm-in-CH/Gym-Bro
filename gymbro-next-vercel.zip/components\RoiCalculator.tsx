'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Users, Tag, Clock, TrendingUp, Sparkles } from 'lucide-react';
import { soundClick, soundSuccess } from '@/lib/audio';

export const RoiCalculator: React.FC = () => {
  const [students, setStudents] = useState<number>(40);
  const [fee, setFee] = useState<number>(1200000);

  const totalMonthly = students * fee;
  const extraMonthly = Math.round(totalMonthly * 0.35); // 35% retention uplift

  const handleStudentsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    soundClick();
    setStudents(parseInt(e.target.value) || 10);
  };

  const handleFeeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    soundClick();
    setFee(parseInt(e.target.value) || 400000);
  };

  return (
    <section id="calculator" className="py-24 bg-surface-950 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <span className="text-xs font-extrabold uppercase tracking-wider text-fire-400 bg-fire-500/10 px-3.5 py-1 rounded-full border border-fire-500/20">
            محاسبه شفاف سودآوری
          </span>
          <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight">چقدر با GymBro درآمدتان بیشتر می‌شود؟</h2>
          <p className="text-slate-400 text-sm sm:text-base">
            تعداد شاگردان و هزینه برنامه خود را مشخص کنید تا ببینید سیستم تمدید خودکار و صرفه‌جویی زمان چقدر به درآمد خالص شما اضافه می‌کند.
          </p>
        </div>

        {/* Calculator Box */}
        <div className="max-w-4xl mx-auto glass-card p-6 sm:p-10 rounded-3xl border border-surface-750 shadow-2xl">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Sliders Area (7 cols) */}
            <div className="md:col-span-7 space-y-6">
              {/* Slider 1: Students Count */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <label className="text-slate-300 font-bold flex items-center gap-2">
                    <Users className="w-4 h-4 text-brand-400" />
                    تعداد شاگردان فعال ماهانه:
                  </label>
                  <span className="text-lg font-black text-brand-400 font-mono">{students} نفر</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="150"
                  value={students}
                  step="5"
                  onChange={handleStudentsChange}
                  className="w-full h-2.5 bg-surface-800 rounded-lg appearance-none cursor-pointer accent-brand-500"
                />
                <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                  <span>۱۰ شاگرد</span>
                  <span>۸۰ شاگرد</span>
                  <span>۱۵۰ شاگرد</span>
                </div>
              </div>

              {/* Slider 2: Fee Per Program */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <label className="text-slate-300 font-bold flex items-center gap-2">
                    <Tag className="w-4 h-4 text-fire-400" />
                    میانگین هزینه هر دوره برنامه (تمرین + تغذیه):
                  </label>
                  <span className="text-lg font-black text-fire-400 font-mono">
                    {(fee / 1000).toLocaleString('fa-IR')} هزار تومان
                  </span>
                </div>
                <input
                  type="range"
                  min="400000"
                  max="3000000"
                  value={fee}
                  step="100000"
                  onChange={handleFeeChange}
                  className="w-full h-2.5 bg-surface-800 rounded-lg appearance-none cursor-pointer accent-fire-500"
                />
                <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                  <span>۴۰۰ هزار ت</span>
                  <span>۱.۵ میلیون ت</span>
                  <span>۳ میلیون ت</span>
                </div>
              </div>

              {/* Benefit Badges */}
              <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
                <div className="p-3 bg-surface-900 rounded-2xl border border-surface-800 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-brand-400 shrink-0" />
                  <span className="text-slate-300">
                    <strong>۳۵ ساعت</strong> صرفه‌جویی زمان در ماه
                  </span>
                </div>
                <div className="p-3 bg-surface-900 rounded-2xl border border-surface-800 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-fire-400 shrink-0" />
                  <span className="text-slate-300">
                    <strong>۳۵٪</strong> افزایش تمدید با پیامک
                  </span>
                </div>
              </div>
            </div>

            {/* Results Summary (5 cols) */}
            <div className="md:col-span-5 p-6 rounded-3xl bg-gradient-to-b from-surface-900 to-surface-950 border border-brand-500/30 text-center space-y-4">
              <span className="text-xs text-slate-400 font-bold block">تخمین درآمد ماهانه با GymBro:</span>

              <div className="space-y-1">
                <div className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
                  {totalMonthly.toLocaleString('fa-IR')}
                </div>
                <span className="text-xs text-brand-400 font-bold">تومان در ماه</span>
              </div>

              <div className="p-3 bg-surface-850/80 rounded-2xl border border-surface-800 space-y-1">
                <span className="text-[10px] text-slate-400 block">درآمد مازاد ناشی از اتوماسیون تمدید:</span>
                <span className="text-lg font-black text-emerald-400 font-mono">
                  + {extraMonthly.toLocaleString('fa-IR')} تومان
                </span>
              </div>

              <Link
                href="/app"
                onClick={() => soundSuccess()}
                className="w-full py-3.5 bg-gradient-to-r from-brand-600 to-emerald-500 hover:from-brand-500 hover:to-emerald-400 text-white font-black rounded-2xl text-xs shadow-glow-emerald transition flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>شروع فعال‌سازی پنل مربی</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
