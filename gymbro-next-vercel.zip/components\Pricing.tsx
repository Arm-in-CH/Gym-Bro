'use client';

import React from 'react';
import Link from 'next/link';
import { Check } from 'lucide-react';
import { soundClick } from '@/lib/audio';

interface PricingProps {
  onOpenCoachModal: () => void;
}

export const Pricing: React.FC<PricingProps> = ({ onOpenCoachModal }) => {
  return (
    <section id="pricing" className="py-24 bg-surface-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="text-xs font-extrabold uppercase tracking-wider text-brand-400 bg-brand-500/10 px-3.5 py-1 rounded-full border border-brand-500/20">
            پلن‌های شفاف و بدون ریسک
          </span>
          <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight">تعرفه‌های متناسب با هر مرحله از رشد شما</h2>
          <p className="text-slate-400 text-sm sm:text-base">
            شروع رایگان برای ورزشکاران، پلن رشد برای مربیان و پکیج انترپرایز برای مجموعه‌های ورزشی و باشگاه‌ها.
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* TIER 1: ATHLETE FREE */}
          <div className="glass-card p-8 rounded-3xl border border-surface-800 space-y-6 flex flex-col justify-between hover:border-brand-500/40 transition">
            <div className="space-y-4">
              <div className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-brand-500/10 text-brand-400">
                ویژه ورزشکاران
              </div>
              <h3 className="text-2xl font-black text-white">ورزشکار آزاد (Athlete)</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                برای همه علاقه‌مندان به تناسب اندام که می‌خواهند کالری و تمرینات خود را ثبت کنند.
              </p>
              <div className="pt-2">
                <span className="text-3xl font-black text-white font-mono">رایگان</span>
                <span className="text-xs text-slate-500 mr-2">دسترسی دائمی</span>
              </div>

              <ul className="space-y-3 pt-4 border-t border-surface-800 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-brand-400" />
                  <span>اسکن روزانه غذاهای ایرانی با هوش مصنوعی</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-brand-400" />
                  <span>لاگر تمرین با تایمر استراحت و محاسبه 1RM</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-brand-400" />
                  <span>سوئیچ حرکات باشگاه به حرکات در منزل</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-brand-400" />
                  <span>یادآور هوشمند آب و گیمیفیکیشن کلم</span>
                </li>
              </ul>
            </div>

            <Link
              href="/app"
              onClick={() => soundClick()}
              className="w-full py-3 rounded-2xl bg-surface-850 hover:bg-surface-800 text-white font-bold text-xs text-center border border-surface-750 transition block"
            >
              ورود رایگان ورزشکار
            </Link>
          </div>

          {/* TIER 2: COACH PRO (FEATURED) */}
          <div className="glass-card p-8 rounded-3xl border-2 border-fire-500/50 shadow-glow-orange space-y-6 flex flex-col justify-between relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-fire-600 to-amber-500 text-white font-black text-[10px] px-4 py-1 rounded-full uppercase tracking-wider shadow-lg">
              محبوب‌ترین مربیان
            </div>

            <div className="space-y-4">
              <div className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-fire-500/10 text-fire-400">
                ویژه مربیان و بدنسازان
              </div>
              <h3 className="text-2xl font-black text-white">مربی حرفه‌ای (Coach Pro)</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                پنل مدیریت تا ۵۰ شاگرد فعال با درگاه پرداخت مستقیم و سیستم تمدید پیامکی خودکار.
              </p>
              <div className="pt-2">
                <span className="text-3xl font-black text-white font-mono">۴۹۰,۰۰۰</span>
                <span className="text-xs text-slate-400 mr-2">تومان / ماهانه</span>
              </div>

              <ul className="space-y-3 pt-4 border-t border-surface-800 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-400" />
                  <span>تمام امکانات پنل ورزشکار</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-400" />
                  <span>طراحی نامحدود برنامه‌ها با کتابخانه ویدیو ۳۰۰ حرکت</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-400" />
                  <span>درگاه پرداخت اختصاصی و واریز پایا روزانه</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-400" />
                  <span>نشان مربی تاییدشده (Verified) در مارکت‌پلیس</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-fire-400" />
                  <span>سیستم یادآوری خودکار پیامکی تمدید شهریه</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => {
                soundClick();
                onOpenCoachModal();
              }}
              className="w-full py-3.5 rounded-2xl bg-fire-500 hover:bg-fire-400 text-slate-950 font-black text-xs text-center shadow-lg transition block"
            >
              ۱۴ روز تست رایگان مربی
            </button>
          </div>

          {/* TIER 3: GYM & ENTERPRISE */}
          <div className="glass-card p-8 rounded-3xl border border-surface-800 space-y-6 flex flex-col justify-between hover:border-cyber-500/40 transition">
            <div className="space-y-4">
              <div className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-purple-500/10 text-purple-400">
                ویژه باشگاه‌ها و زنجیره‌ها
              </div>
              <h3 className="text-2xl font-black text-white">باشگاه ابری (Gym Cloud)</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                اتصال گیت‌های تردد، مدیریت کمدها، بوفه، پورسانت مربیان سالن و گزارش‌های مالی.
              </p>
              <div className="pt-2">
                <span className="text-3xl font-black text-white font-mono">تماس / دمو</span>
                <span className="text-xs text-slate-500 mr-2">بر اساس تعداد گیت‌ها</span>
              </div>

              <ul className="space-y-3 pt-4 border-t border-surface-800 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400" />
                  <span>پشتیبانی از انواع گیت (RFID / بارکد / چهره)</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400" />
                  <span>پنل مجزا برای منشی، مدیر سالن و مربیان</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400" />
                  <span>حسابداری بوفه و ثبت سفارش با شماره کمد</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400" />
                  <span>پشتیبان‌گیری ابری روزانه بدون نیاز به سرور محلی</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => {
                soundClick();
                onOpenCoachModal();
              }}
              className="w-full py-3 rounded-2xl bg-surface-850 hover:bg-surface-800 text-white font-bold text-xs text-center border border-surface-750 transition block"
            >
              درخواست مشاوره و دمو حضوری
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
