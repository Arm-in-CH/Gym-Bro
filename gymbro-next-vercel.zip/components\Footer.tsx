'use client';

import React from 'react';
import Link from 'next/link';
import { Play, Phone, Mail } from 'lucide-react';
import { soundSuccess, soundClick } from '@/lib/audio';

interface FooterProps {
  onOpenCoachModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenCoachModal }) => {
  return (
    <footer className="bg-surface-950 border-t border-surface-800 py-16 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
        <div className="max-w-2xl mx-auto space-y-4">
          <h3 className="text-3xl sm:text-5xl font-black text-white">آماده‌اید تجربه ورزشی خود را متحول کنید؟</h3>
          <p className="text-slate-400 text-sm">
            همین حالا نسخه آزمایشی وب‌اپلیکیشن را روی هر دستگاهی (گوشی، تبلت یا لپ‌تاپ) بدون نیاز به نصب تست کنید.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <Link
            href="/app"
            onClick={() => soundSuccess()}
            className="px-8 py-4 rounded-2xl bg-gradient-to-r from-brand-600 to-emerald-500 hover:from-brand-500 hover:to-emerald-400 text-white font-black text-sm shadow-glow-emerald transition flex items-center gap-2"
          >
            <Play className="w-4 h-4" />
            <span>اجرای زنده وب‌اپلیکیشن GymBro</span>
          </Link>

          <button
            onClick={() => {
              soundClick();
              onOpenCoachModal();
            }}
            className="px-6 py-4 rounded-2xl bg-surface-900 hover:bg-surface-850 text-slate-300 font-bold text-sm border border-surface-800 transition"
          >
            ثبت نام باشگاه یا مربی
          </button>
        </div>

        {/* Direct Contact with Founder & Support */}
        <div className="my-8 p-6 rounded-3xl bg-surface-900/90 border border-brand-500/30 max-w-3xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-5 text-right shadow-2xl">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-sm font-black text-white">مدیر توسعه و ارتباط مستقیم با مربیان: آرمین</span>
            </div>
            <p className="text-xs text-slate-400 leading-normal">
              پاسخگویی سریع به سوالات فنی، همکاری با باشگاه‌ها و هماهنگی نسخه آزمایشی اختصاصی
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs shrink-0 font-mono">
            <a
              href="tel:09027897840"
              className="px-4 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-400 text-slate-950 font-black flex items-center gap-2 transition shadow-md hover:scale-105"
            >
              <Phone className="w-4 h-4" />
              <span dir="ltr">09027897840</span>
            </a>
            <a
              href="mailto:arminchinip.ai@gmail.com"
              className="px-4 py-2.5 rounded-xl bg-surface-800 hover:bg-surface-750 text-white font-bold flex items-center gap-2 transition border border-surface-700 hover:scale-105"
            >
              <Mail className="w-4 h-4 text-brand-400" />
              <span dir="ltr">arminchinip.ai@gmail.com</span>
            </a>
          </div>
        </div>

        <div className="pt-8 border-t border-surface-900 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">GymBro Ecosystem</span>
            <span>© ۲۰۲۶ — تمامی حقوق برای تیم توسعه جیم‌برو محفوظ است.</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400 font-medium">
            <Link href="/app" className="hover:text-brand-400 transition">
              دمو آنلاین
            </Link>
            <a href="tel:09027897840" className="hover:text-brand-400 transition">
              تماس: ۰۹۰۲۷۸۹۷۸۴۰
            </a>
            <a href="mailto:arminchinip.ai@gmail.com" className="hover:text-brand-400 transition">
              ایمیل پشتیبانی
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
