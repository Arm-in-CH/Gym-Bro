import { NextResponse } from 'next/server';
import { IRANIAN_FOODS } from '@/lib/data';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get('q')?.toLowerCase();

  let results = Object.values(IRANIAN_FOODS);

  if (query) {
    results = results.filter(
      (f) =>
        f.title.toLowerCase().includes(query) ||
        f.subtitle.toLowerCase().includes(query) ||
        f.badge.toLowerCase().includes(query)
    );
  }

  return NextResponse.json({
    success: true,
    total: results.length,
    foods: results,
  });
}
